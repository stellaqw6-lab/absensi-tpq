import { NextRequest, NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { orders, users, stores } from "@/db/schema";
import { requireAdmin } from "@/lib/require-admin";

export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req);
  if ("error" in admin) return admin.error;

  const rows = await db
    .select({
      id: orders.id,
      orderNumber: orders.orderNumber,
      status: orders.status,
      paymentStatus: orders.paymentStatus,
      paymentProofUrl: orders.paymentProofUrl,
      grandTotal: orders.grandTotal,
      createdAt: orders.createdAt,
      customerName: users.name,
      customerEmail: users.email,
      storeName: stores.name,
    })
    .from(orders)
    .leftJoin(users, eq(orders.userId, users.id))
    .leftJoin(stores, eq(orders.sellerId, stores.sellerId))
    .orderBy(desc(orders.createdAt));

  return NextResponse.json({ orders: rows });
}
