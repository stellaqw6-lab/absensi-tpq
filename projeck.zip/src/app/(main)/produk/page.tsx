import { Metadata } from "next";
import { Suspense } from "react";
import { ProductsPage } from "@/components/product/products-page";

export const metadata: Metadata = {
  title: "Produk",
  description: "Jelajahi koleksi produk berkualitas dari seluruh Indonesia. Fashion, makanan, kerajinan, dan masih banyak lagi.",
  openGraph: {
    title: "Produk Pilihan Berkualitas | UNO Shop",
    description: "Jelajahi koleksi produk berkualitas dari seluruh Indonesia.",
  },
};

export default function ProdukPage() {
  return (
    <Suspense fallback={null}>
      <ProductsPage />
    </Suspense>
  );
}
