import { HeroSection } from "@/components/home/hero-section";
import { CategorySection } from "@/components/home/category-section";
import { FeaturedProducts } from "@/components/home/featured-products";
import { MarqueeStrip } from "@/components/home/marquee-strip";
import { KineticMarquee } from "@/components/home/kinetic-marquee";
import { WhyBento } from "@/components/home/why-bento";
import { StatsSection } from "@/components/home/stats-section";
import { StorySection } from "@/components/home/story-section";
import { TestimonialSection } from "@/components/home/testimonial-section";
import { BlogSection } from "@/components/home/blog-section";
import { FaqSection } from "@/components/home/faq-section";
import { CtaSection } from "@/components/home/cta-section";
import { ProductRing } from "@/components/home/product-ring";
import { HorizontalGallery } from "@/components/home/horizontal-gallery";
import { ShowcaseReveal } from "@/components/home/showcase-reveal";
import {
  getFeaturedProducts,
  getCategories,
  getTestimonials,
  getFaqs,
  getPublishedBlogPosts,
  getPlatformStats,
  getSiteSettings,
} from "@/lib/data";

// Ambil data terbaru setiap request supaya perubahan dari admin langsung terlihat
export const revalidate = 0;

export default async function HomePage() {
  const [featuredProducts, categories, testimonials, faqs, blogPosts, stats, settings] = await Promise.all([
    getFeaturedProducts(8),
    getCategories(),
    getTestimonials(6),
    getFaqs(),
    getPublishedBlogPosts(3),
    getPlatformStats(),
    getSiteSettings(),
  ]);

  // Data galeri horizontal: kategori bergambar + jumlah produk dari featured.
  const galleryItems = categories
    .filter((c) => c.image)
    .map((c) => ({
      name: c.name,
      slug: c.slug,
      image: c.image as string,
      count: featuredProducts.filter((p) => p.categoryId === c.id).length,
    }));

  // Showcase reveal: 3 produk unggulan teratas sebagai kartu editorial.
  const showcaseItems = featuredProducts.slice(0, 3).map((p) => ({
    title: p.name,
    subtitle: p.storeName ?? "Produk Pilihan",
    image: p.image,
    href: `/produk/${p.slug}`,
  }));

  return (
    <>
      <HeroSection
        badgeText={settings.heroBadgeText}
        titleLine1={settings.heroTitleLine1}
        titleHighlight={settings.heroTitleHighlight}
        titleLine2={settings.heroTitleLine2}
        description={settings.heroDescription ?? undefined}
        buttonText={settings.heroButtonText}
        buttonUrl={settings.heroButtonUrl}
        previewImage={featuredProducts[0]?.image}
        previewProductName={featuredProducts[0]?.name}
        previewStoreName={featuredProducts[0]?.storeName}
        previewPrice={featuredProducts[0]?.price}
      />
      <CategorySection categories={categories} />
      <MarqueeStrip categories={categories} />
      <KineticMarquee />
      <WhyBento />
      <ShowcaseReveal items={showcaseItems} />
      <FeaturedProducts products={featuredProducts} />
      <ProductRing products={featuredProducts.map((p) => ({ name: p.name, image: p.image, price: p.price, slug: p.slug }))} />
      <HorizontalGallery items={galleryItems} />
      <StatsSection stats={stats} />
      <StorySection />
      <TestimonialSection testimonials={testimonials} />
      <BlogSection posts={blogPosts} />
      <FaqSection faqs={faqs} />
      <CtaSection />
    </>
  );
}
