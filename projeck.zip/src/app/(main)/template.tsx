"use client";

import type { ReactNode } from "react";
import { motion } from "framer-motion";
import { useMotionPrefs } from "@/hooks/use-motion-prefs";
import { durations, easeOutExpo } from "@/lib/motion";

/**
 * Transisi antar halaman area (main): template.tsx di-remount oleh Next
 * setiap navigasi, jadi entrance animation ini jalan tiap pindah halaman.
 * Reduced-motion / device lemah: render tanpa animasi.
 */
export default function MainTemplate({ children }: { children: ReactNode }) {
  const prefs = useMotionPrefs();

  if (!prefs.allowMotion) {
    return <>{children}</>;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: durations.fast, ease: easeOutExpo }}
    >
      {children}
    </motion.div>
  );
}
