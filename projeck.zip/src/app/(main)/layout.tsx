import type { ReactNode } from "react";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { MobileBottomNav } from "@/components/layout/mobile-bottom-nav";
import { CursorGlow } from "@/components/ui/cursor-glow";
import { SellerUpgradeProvider } from "@/contexts/seller-upgrade-context";
import { SellerUpgradeModal } from "@/components/seller/seller-upgrade-modal";

export default function MainLayout({ children }: { children: ReactNode }) {
  return (
    <SellerUpgradeProvider>
      <CursorGlow />
      <Header />
      <main className="min-h-screen">{children}</main>
      <Footer />
      {/* Spacer supaya konten tidak tertutup bottom nav mobile */}
      <div className="h-14 lg:hidden" aria-hidden="true" />
      <MobileBottomNav />
      {/* Popup terpisah untuk fitur upgrade role premium (jadi seller) */}
      <SellerUpgradeModal />
    </SellerUpgradeProvider>
  );
}
