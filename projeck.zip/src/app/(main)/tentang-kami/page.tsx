import { Metadata } from "next";
import { AboutPage } from "@/components/home/about-page";
import { getPlatformStats } from "@/lib/data";

export const metadata: Metadata = {
  title: "Tentang Kami",
  description: "Kenali lebih dekat UNO Shop - platform belanja online modern dengan pengalaman transaksi yang mudah dan aman.",
};

// Ambil data terbaru setiap request supaya angka statistik selalu real-time
export const revalidate = 0;

export default async function AboutUsPage() {
  const stats = await getPlatformStats();
  return <AboutPage stats={stats} foundedYear={2026} />;
}
