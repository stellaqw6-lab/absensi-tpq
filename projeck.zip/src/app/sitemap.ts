import { MetadataRoute } from "next";
import { db } from "@/db";
import { products, blogPosts } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = process.env.NEXT_PUBLIC_APP_URL || "https://example.com";

  const staticPages: MetadataRoute.Sitemap = [
    { url: baseUrl, changeFrequency: "daily", priority: 1 },
    { url: `${baseUrl}/produk`, changeFrequency: "daily", priority: 0.9 },
    { url: `${baseUrl}/blog`, changeFrequency: "daily", priority: 0.7 },
    { url: `${baseUrl}/promo`, changeFrequency: "daily", priority: 0.7 },
    { url: `${baseUrl}/tentang-kami`, changeFrequency: "monthly", priority: 0.5 },
    { url: `${baseUrl}/kontak`, changeFrequency: "monthly", priority: 0.5 },
    { url: `${baseUrl}/faq`, changeFrequency: "monthly", priority: 0.4 },
  ];

  // DB tidak terjangkau saat build (mis. CI tanpa database) tidak boleh
  // menggagalkan seluruh build — kembalikan halaman statis saja.
  let productPages: MetadataRoute.Sitemap = [];
  let blogPages: MetadataRoute.Sitemap = [];
  try {
    const activeProducts = await db.select({ slug: products.slug, updatedAt: products.updatedAt }).from(products).where(eq(products.isActive, true));
    productPages = activeProducts.map((p) => ({
      url: `${baseUrl}/produk/${p.slug}`,
      lastModified: p.updatedAt,
      changeFrequency: "weekly",
      priority: 0.8,
    }));

    const publishedPosts = await db.select({ slug: blogPosts.slug, updatedAt: blogPosts.updatedAt }).from(blogPosts).where(eq(blogPosts.isPublished, true));
    blogPages = publishedPosts.map((p) => ({
      url: `${baseUrl}/blog/${p.slug}`,
      lastModified: p.updatedAt,
      changeFrequency: "monthly",
      priority: 0.6,
    }));
  } catch (err) {
    console.warn("Sitemap: database tidak terjangkau, hanya halaman statis yang disertakan.", err instanceof Error ? err.message : err);
  }

  return [...staticPages, ...productPages, ...blogPages];
}
