"use client";

import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";

// ---- small helpers -------------------------------------------------------

// Slight overshoot on settle — a touch livelier than a plain ease-out
// without tipping into cartoonish bounce.
function easeOutBack(t: number) {
  const c1 = 1.4;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
}

function clamp01(v: number) {
  return Math.min(1, Math.max(0, v));
}

/** Draws a small canvas texture once (memoized) — used for label/card/receipt detail. */
function useDrawnTexture(width: number, height: number, draw: (ctx: CanvasRenderingContext2D, w: number, h: number) => void) {
  return useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (ctx) draw(ctx, width, height);
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.anisotropy = 4;
    return texture;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
}

interface Hero3DObjectsProps {
  lowQuality?: boolean;
  reducedMotion?: boolean;
  enableParallax?: boolean;
  composition?: { showBag: boolean; showProduct: boolean; showCard: boolean; showReceipt: boolean };
  /** Derajat rotasi Y dari drag user di Hero3DScene (ref, dibaca per-frame). */
  dragRotation?: { current: number };
}

/**
 * "THE LOCAL PARCEL" — a shipping box (primary), a paper bag (secondary),
 * one local product jar (tertiary), and small realism details (thank-you
 * card + receipt). Entrance is staggered once on mount, then only a barely
 * perceptible idle sway remains. Cursor parallax nudges the whole group —
 * never individual objects — so it reads as a camera move, not toys flying.
 *
 * `composition` lets smaller viewports show fewer supporting objects (the
 * box always stays as the focal object) instead of just scaling everything
 * down — a cramped scene reads worse than a simpler one.
 */
export function Hero3DObjects({
  lowQuality = false,
  reducedMotion = false,
  enableParallax = true,
  composition = { showBag: true, showProduct: true, showCard: true, showReceipt: true },
  dragRotation,
}: Hero3DObjectsProps) {
  const groupRef = useRef<THREE.Group>(null);
  const boxRef = useRef<THREE.Group>(null);
  const bagRef = useRef<THREE.Group>(null);
  const productRef = useRef<THREE.Group>(null);

  const parallaxTarget = useRef({ x: 0, y: 0 });
  const startTime = useRef<number | null>(null);

  const seg = lowQuality ? 2 : 4;

  // ---- geometries (memoized once) ----
  const boxGeo = useMemo(() => new RoundedBoxGeometry(1.7, 1.05, 1.15, seg, 0.035), [seg]);
  const bagGeo = useMemo(() => new RoundedBoxGeometry(0.85, 1.0, 0.5, seg, 0.02), [seg]);
  const bagFlapGeo = useMemo(() => new RoundedBoxGeometry(0.85, 0.14, 0.5, seg, 0.015), [seg]);

  // ---- label / card textures ----
  const shippingLabelTex = useDrawnTexture(256, 192, (ctx, w, h) => {
    ctx.fillStyle = "#faf7f0";
    ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = "#00000018";
    ctx.lineWidth = 2;
    ctx.strokeRect(4, 4, w - 8, h - 8);
    ctx.fillStyle = "#00000055";
    ctx.font = "bold 20px sans-serif";
    ctx.fillText("RESI", 20, 34);
    ctx.strokeStyle = "#00000030";
    for (let i = 0; i < 5; i++) {
      ctx.lineWidth = 2 + (i % 2) * 3;
      const x = 20 + i * 12;
      ctx.beginPath();
      ctx.moveTo(x, 60);
      ctx.lineTo(x, 100);
      ctx.stroke();
    }
    ctx.fillStyle = "#00000040";
    ctx.font = "13px sans-serif";
    ctx.fillText("Dikirim dari UNO Shop", 20, 130);
  });

  const cardTex = useDrawnTexture(320, 200, (ctx, w, h) => {
    ctx.fillStyle = "#fffdf8";
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = "#2b2118";
    ctx.font = "italic 22px Georgia, serif";
    ctx.fillText("Terima kasih telah", 24, 80);
    ctx.fillText("mendukung produk lokal.", 24, 112);
  });

  const receiptTex = useDrawnTexture(180, 260, (ctx, w, h) => {
    ctx.fillStyle = "#fffdf8";
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = "#00000030";
    ctx.font = "11px monospace";
    for (let i = 0; i < 8; i++) {
      const lineW = 60 + Math.abs(Math.sin(i)) * 60;
      ctx.fillRect(16, 24 + i * 20, lineW, 3);
    }
  });

  const jarLabelTex = useDrawnTexture(128, 64, (ctx, w, h) => {
    ctx.fillStyle = "#2563eb";
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = "#ffffffdd";
    ctx.font = "bold 16px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("LOKAL", w / 2, h / 2 + 6);
  });

  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    if (startTime.current === null) startTime.current = t;
    const local = t - (startTime.current ?? t);

    // ---- staggered entrance (position only; opacity handled at DOM level) ----
    const entranceDuration = reducedMotion ? 0.01 : 0.55;
    const boxP = reducedMotion ? 1 : easeOutBack(clamp01(local / entranceDuration));
    const bagP = reducedMotion ? 1 : easeOutBack(clamp01((local - 0.1) / entranceDuration));
    const productP = reducedMotion ? 1 : easeOutBack(clamp01((local - 0.2) / entranceDuration));

    if (boxRef.current) boxRef.current.position.y = THREE.MathUtils.lerp(0.3, 0, boxP);
    if (bagRef.current) bagRef.current.position.y = THREE.MathUtils.lerp(0.2, 0, bagP) - 0.02;
    if (productRef.current) productRef.current.position.y = THREE.MathUtils.lerp(0.14, 0, productP) + 0.02;

    // ---- idle motion (only once entrance has settled) — a gentle sway plus
    // a slow vertical breathing bob, enough to feel alive without "dancing" ----
    let idleY = 0;
    let idleBob = 0;
    if (!reducedMotion && local > 0.75) {
      const settle = clamp01((local - 0.75) / 0.6); // ease idle in smoothly after entrance
      idleY = THREE.MathUtils.degToRad(0.6) * Math.sin((t / 9) * Math.PI * 2) * settle;
      idleBob = 0.02 * Math.sin((t / 6.5) * Math.PI * 2) * settle;
    }
    if (groupRef.current) groupRef.current.position.y = idleBob;

    // ---- cursor parallax on the whole group (reads as camera movement) ----
    if (enableParallax && !reducedMotion) {
      parallaxTarget.current.x = state.pointer.x;
      parallaxTarget.current.y = state.pointer.y;
    }
    const maxTilt = THREE.MathUtils.degToRad(3);

    if (groupRef.current) {
      // Drag user (derajat) digabung ke target rotasi Y; damped agar berhenti
      // mulus, bukan menyentak.
      const dragDeg = reducedMotion ? 0 : (dragRotation?.current ?? 0);
      const targetRotY =
        idleY + parallaxTarget.current.x * maxTilt + THREE.MathUtils.degToRad(dragDeg);
      const targetRotX = -parallaxTarget.current.y * maxTilt * 0.6;
      groupRef.current.rotation.y = THREE.MathUtils.damp(groupRef.current.rotation.y, targetRotY, 4, state.clock.getDelta() || 0.016);
      groupRef.current.rotation.x = THREE.MathUtils.damp(groupRef.current.rotation.x, targetRotX, 4, state.clock.getDelta() || 0.016);
    }
  });

  return (
    <group ref={groupRef}>
      {/* Shadow-catcher ground — invisible except for the contact shadow it receives */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.53, 0]} receiveShadow>
        <planeGeometry args={[6, 6]} />
        <shadowMaterial opacity={0.22} />
      </mesh>

      {/* PRIMARY — shipping box, slightly imperfect placement */}
      <group ref={boxRef} position={[0.05, 0, 0]} rotation={[0, THREE.MathUtils.degToRad(-6), THREE.MathUtils.degToRad(-1)]}>
        <mesh geometry={boxGeo} castShadow receiveShadow>
          <meshStandardMaterial color="#b8916a" roughness={0.92} metalness={0} />
        </mesh>
        {/* tape strip across the top */}
        <mesh position={[0, 0.528, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <planeGeometry args={[0.28, 1.16]} />
          <meshStandardMaterial color="#e9dcc2" roughness={0.75} metalness={0} transparent opacity={0.92} />
        </mesh>
        {/* shipping label on the front face */}
        <mesh position={[-0.35, -0.05, 0.576]} rotation={[0, 0, THREE.MathUtils.degToRad(-2)]}>
          <planeGeometry args={[0.62, 0.46]} />
          <meshStandardMaterial map={shippingLabelTex} roughness={0.85} metalness={0} />
        </mesh>
        {/* small brand mark, front-right */}
        <mesh position={[0.55, 0.28, 0.576]}>
          <circleGeometry args={[0.09, lowQuality ? 12 : 24]} />
          <meshStandardMaterial color="#2563eb" roughness={0.5} metalness={0} />
        </mesh>
      </group>

      {/* SECONDARY — paper bag, behind and left, slightly tilted */}
      {composition.showBag && (
        <group ref={bagRef} position={[-1.05, -0.02, -0.55]} rotation={[0, THREE.MathUtils.degToRad(10), THREE.MathUtils.degToRad(2.5)]}>
          <mesh geometry={bagGeo} castShadow receiveShadow>
            <meshStandardMaterial color="#efe7d8" roughness={0.82} metalness={0} />
          </mesh>
          <mesh geometry={bagFlapGeo} position={[0, 0.5, 0]} castShadow>
            <meshStandardMaterial color="#e6dbc0" roughness={0.85} metalness={0} />
          </mesh>
          {/* paper rope handles */}
          <mesh position={[-0.2, 0.66, 0]} rotation={[0, 0, Math.PI / 2]}>
            <torusGeometry args={[0.16, 0.012, 8, lowQuality ? 12 : 20, Math.PI]} />
            <meshStandardMaterial color="#c9b893" roughness={0.7} metalness={0} />
          </mesh>
          <mesh position={[0.2, 0.66, 0]} rotation={[0, 0, Math.PI / 2]}>
            <torusGeometry args={[0.16, 0.012, 8, lowQuality ? 12 : 20, Math.PI]} />
            <meshStandardMaterial color="#c9b893" roughness={0.7} metalness={0} />
          </mesh>
          {/* small logo mark on the bag */}
          <mesh position={[0, 0.1, 0.256]}>
            <circleGeometry args={[0.075, lowQuality ? 12 : 24]} />
            <meshStandardMaterial color="#2563eb" roughness={0.6} metalness={0} />
          </mesh>
        </group>
      )}

      {/* TERTIARY — one local product jar, front-right of the box */}
      {composition.showProduct && (
        <group ref={productRef} position={[0.95, -0.24, 0.55]} rotation={[0, THREE.MathUtils.degToRad(-14), 0]}>
          <mesh castShadow receiveShadow position={[0, 0.17, 0]}>
            <cylinderGeometry args={[0.16, 0.16, 0.34, lowQuality ? 10 : 20]} />
            <meshStandardMaterial color="#f4efe4" roughness={0.55} metalness={0} />
          </mesh>
          {/* label band */}
          <mesh position={[0, 0.15, 0]}>
            <cylinderGeometry args={[0.163, 0.163, 0.13, lowQuality ? 10 : 20]} />
            <meshStandardMaterial map={jarLabelTex} roughness={0.6} metalness={0} />
          </mesh>
          {/* lid */}
          <mesh position={[0, 0.355, 0]} castShadow>
            <cylinderGeometry args={[0.165, 0.165, 0.045, lowQuality ? 10 : 20]} />
            <meshStandardMaterial color="#d8cbae" roughness={0.5} metalness={0.05} />
          </mesh>
        </group>
      )}

      {/* DETAIL — thank-you card, tucked out of the box, slightly rotated */}
      {composition.showCard && (
        <mesh
          position={[0.12, 0.32, 0.15]}
          rotation={[THREE.MathUtils.degToRad(-70), THREE.MathUtils.degToRad(6), THREE.MathUtils.degToRad(-4)]}
        >
          <planeGeometry args={[0.42, 0.27]} />
          <meshStandardMaterial map={cardTex} roughness={0.85} metalness={0} side={THREE.DoubleSide} />
        </mesh>
      )}

      {/* DETAIL — small receipt resting on the table */}
      {composition.showReceipt && (
        <mesh position={[-0.5, -0.515, 0.85]} rotation={[-Math.PI / 2, 0, THREE.MathUtils.degToRad(-8)]}>
          <planeGeometry args={[0.3, 0.44]} />
          <meshStandardMaterial map={receiptTex} roughness={0.9} metalness={0} side={THREE.DoubleSide} />
        </mesh>
      )}
    </group>
  );
}
