"use client";

import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";

interface Hero3DEnvironmentProps {
  /** "full" = wall + shelf edge + background box + plant. "simple" = wall + background box only. */
  detail: "full" | "simple";
  lowQuality?: boolean;
  reducedMotion?: boolean;
  enableParallax?: boolean;
}

/**
 * Background set dressing for the hero parcel — a soft studio wall, a thin
 * shelf-edge for grounding, one dimmed background box, and (on the full
 * tier) a small abstracted plant. Everything here sits further back than
 * the main parcel, is lower contrast, and moves far less under cursor
 * parallax (~0.4° vs the parcel's ~3°) so it never competes for attention.
 * This component can be removed entirely without affecting Hero3DObjects.
 */
export function Hero3DEnvironment({ detail, lowQuality = false, reducedMotion = false, enableParallax = true }: Hero3DEnvironmentProps) {
  const groupRef = useRef<THREE.Group>(null);
  const parallaxTarget = useRef({ x: 0, y: 0 });
  const seg = lowQuality ? 2 : 3;

  const boxGeo = useMemo(() => new RoundedBoxGeometry(0.55, 0.55, 0.55, seg, 0.02), [seg]);
  const shelfGeo = useMemo(() => new RoundedBoxGeometry(4.4, 0.05, 0.12, 1, 0.015), []);

  useFrame((state, delta) => {
    if (enableParallax && !reducedMotion) {
      parallaxTarget.current.x = state.pointer.x;
      parallaxTarget.current.y = state.pointer.y;
    }
    const maxTilt = THREE.MathUtils.degToRad(0.9); // deliberately a fraction of the parcel's 3°
    if (groupRef.current) {
      const targetRotY = parallaxTarget.current.x * maxTilt;
      const targetRotX = -parallaxTarget.current.y * maxTilt * 0.5;
      groupRef.current.rotation.y = THREE.MathUtils.damp(groupRef.current.rotation.y, targetRotY, 3.5, delta || 0.016);
      groupRef.current.rotation.x = THREE.MathUtils.damp(groupRef.current.rotation.x, targetRotX, 3.5, delta || 0.016);
    }
  });

  return (
    <group ref={groupRef}>
      {/* Wall — large, low-contrast, warm off-white. Far enough back and low-poly enough to be cheap. */}
      <mesh position={[0, 0.9, -2.4]}>
        <planeGeometry args={[6, 3.6]} />
        <meshStandardMaterial color="#f2ece0" roughness={0.95} metalness={0} />
      </mesh>

      {/* Shelf edge — thin grounding line where wall meets table, middleground layer */}
      {detail === "full" && (
        <mesh geometry={shelfGeo} position={[0, -0.53, -1.1]} receiveShadow>
          <meshStandardMaterial color="#d9cdb5" roughness={0.85} metalness={0} />
        </mesh>
      )}

      {/* One dimmed background box — desaturated, out of focal point, back-left */}
      <mesh geometry={boxGeo} position={[-1.75, -0.24, -1.35]} rotation={[0, THREE.MathUtils.degToRad(18), THREE.MathUtils.degToRad(-1)]} receiveShadow>
        <meshStandardMaterial color="#ddd3bf" roughness={0.9} metalness={0} />
      </mesh>

      {/* Small abstracted plant — back-right corner, only on the full tier */}
      {detail === "full" && (
        <group position={[1.9, -0.36, -1.5]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.14, 0.11, 0.22, lowQuality ? 8 : 12]} />
            <meshStandardMaterial color="#c9b599" roughness={0.9} metalness={0} />
          </mesh>
          {[0, 1, 2, 3, 4].map((i) => (
            <mesh
              key={i}
              position={[Math.cos(i * 1.4) * 0.06, 0.28 + i * 0.02, Math.sin(i * 1.4) * 0.06]}
              rotation={[THREE.MathUtils.degToRad(-25 - i * 4), i * 1.4, THREE.MathUtils.degToRad(8)]}
            >
              <coneGeometry args={[0.035, 0.32, lowQuality ? 4 : 6]} />
              <meshStandardMaterial color="#8a9a7d" roughness={0.85} metalness={0} />
            </mesh>
          ))}
        </group>
      )}
    </group>
  );
}
