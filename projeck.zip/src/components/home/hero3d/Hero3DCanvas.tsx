"use client";

import { useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { Hero3DLighting } from "./Hero3DLighting";
import { Hero3DObjects } from "./Hero3DObjects";
import { Hero3DEnvironment } from "./Hero3DEnvironment";
import type { Hero3DCapability } from "./capability";

/**
 * Kamera scroll-linked: dolly-in + orbit ringan mengikuti progres scroll
 * hero — terasa seperti menjelajah objek, bukan sekadar gambar zoom.
 * Ref-based, tanpa re-render. Reduced-motion: kamera diam.
 */
function ScrollCamera({
  scrollProgress,
  basePos,
  reducedMotion,
}: {
  scrollProgress: { current: number };
  basePos: [number, number, number];
  reducedMotion: boolean;
}) {
  const camRef = useRef<THREE.PerspectiveCamera | null>(null);

  useFrame((state, delta) => {
    if (reducedMotion) return;
    const cam = camRef.current ?? state.camera;
    if (!camRef.current) camRef.current = state.camera as THREE.PerspectiveCamera;

    const p = scrollProgress.current;
    // Dolly-in 15% + orbit 12° + sedikit turun — kombinasi kecil yang terasa.
    const dolly = 1 - p * 0.15;
    const orbit = p * THREE.MathUtils.degToRad(12);
    const targetX = basePos[0] * dolly * Math.cos(orbit) - basePos[2] * dolly * Math.sin(orbit);
    const targetZ = basePos[0] * dolly * Math.sin(orbit) + basePos[2] * dolly * Math.cos(orbit);
    const targetY = basePos[1] * dolly - p * 0.25;

    cam.position.x = THREE.MathUtils.damp(cam.position.x, targetX, 3, delta || 0.016);
    cam.position.y = THREE.MathUtils.damp(cam.position.y, targetY, 3, delta || 0.016);
    cam.position.z = THREE.MathUtils.damp(cam.position.z, targetZ, 3, delta || 0.016);
    cam.lookAt(0, -0.05, 0);
  });

  return null;
}

export function Hero3DCanvas({
  capability,
  dragRotation,
  scrollProgress,
  onReady,
}: {
  capability: Hero3DCapability;
  /** Derajat rotasi Y tambahan dari drag user (dibaca per-frame, tanpa re-render). */
  dragRotation?: { current: number };
  /** Progres scroll hero 0..1 (dibaca per-frame oleh kamera). */
  scrollProgress?: { current: number };
  onReady?: () => void;
}) {
  const { tier, dpr, shadows, enableParallax, reducedMotion, composition, cameraDistanceScale, environment } = capability;
  const lowQuality = tier !== "A";

  const basePos: [number, number, number] = [1.9, 1.7, 3.4];
  const cameraPosition: [number, number, number] = [
    basePos[0] * cameraDistanceScale,
    basePos[1] * cameraDistanceScale,
    basePos[2] * cameraDistanceScale,
  ];

  return (
    <Canvas
      shadows={shadows}
      dpr={dpr}
      gl={{ antialias: tier === "A", alpha: true, toneMapping: THREE.ACESFilmicToneMapping }}
      camera={{ position: cameraPosition, fov: 32 }}
      onCreated={({ camera, scene, gl }) => {
        camera.lookAt(0, -0.05, 0);
        scene.background = null;
        // WebGL context actually exists and rendered its first frame — safe to
        // crossfade away the static fallback now (not just after a timer).
        gl.getContext();
        onReady?.();
      }}
    >
      <Hero3DLighting enabled={shadows} />
      {scrollProgress && (
        <ScrollCamera scrollProgress={scrollProgress} basePos={cameraPosition} reducedMotion={reducedMotion} />
      )}
      {environment !== "none" && (
        <Hero3DEnvironment
          detail={environment}
          lowQuality={lowQuality}
          reducedMotion={reducedMotion}
          enableParallax={enableParallax}
        />
      )}
      <Hero3DObjects
        lowQuality={lowQuality}
        reducedMotion={reducedMotion}
        enableParallax={enableParallax}
        composition={composition}
        dragRotation={dragRotation}
      />
    </Canvas>
  );
}
