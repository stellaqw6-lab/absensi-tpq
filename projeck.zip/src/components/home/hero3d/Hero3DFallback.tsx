export function Hero3DFallback({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 640 480"
      className={className}
      role="img"
      aria-label="Ilustrasi paket produk UNO Shop siap dikirim"
    >
      <rect width="640" height="480" fill="#F7F3EC" />

      {/* soft contact shadow */}
      <ellipse cx="330" cy="378" rx="190" ry="22" fill="#00000010" />

      {/* paper bag, behind */}
      <g transform="translate(120,150)">
        <rect x="0" y="40" width="150" height="170" rx="4" fill="#EFE7D8" stroke="#E2D6BE" strokeWidth="1.5" />
        <rect x="0" y="40" width="150" height="28" fill="#E7DCC5" />
        <path d="M35 40 C35 10 60 -8 75 -8 C90 -8 115 10 115 40" stroke="#C9B893" strokeWidth="5" fill="none" strokeLinecap="round" />
        <circle cx="75" cy="95" r="14" fill="#2563EB" opacity="0.9" />
        <text x="75" y="100" textAnchor="middle" fontSize="13" fill="#fff" fontFamily="sans-serif" fontWeight="700">u</text>
      </g>

      {/* shipping box, primary */}
      <g transform="translate(255,110) rotate(-1.5)">
        <rect x="0" y="60" width="230" height="180" fill="#C7A374" />
        <rect x="0" y="60" width="230" height="180" fill="#00000008" />
        <polygon points="0,60 30,20 260,20 230,60" fill="#D3B489" />
        <polygon points="230,60 260,20 260,200 230,240" fill="#B08F60" />
        {/* tape */}
        <rect x="100" y="20" width="30" height="220" fill="#E8DAC0" opacity="0.85" />
        {/* shipping label */}
        <rect x="24" y="110" width="90" height="60" rx="3" fill="#FAF7F0" stroke="#00000014" />
        <line x1="34" y1="126" x2="94" y2="126" stroke="#00000030" strokeWidth="2" />
        <line x1="34" y1="138" x2="80" y2="138" stroke="#00000020" strokeWidth="2" />
        <line x1="34" y1="150" x2="90" y2="150" stroke="#00000020" strokeWidth="2" />
        {/* small brand mark */}
        <circle cx="196" cy="90" r="13" fill="#2563EB" />
        <text x="196" y="95" textAnchor="middle" fontSize="13" fill="#fff" fontFamily="sans-serif" fontWeight="700">u</text>
      </g>

      {/* local product jar, tertiary */}
      <g transform="translate(400,215)">
        <rect x="0" y="10" width="52" height="66" rx="6" fill="#F4EFE4" stroke="#00000012" />
        <rect x="0" y="30" width="52" height="18" fill="#2563EB" opacity="0.85" />
        <rect x="-3" y="0" width="58" height="12" rx="4" fill="#D8CBAE" />
      </g>

      {/* thank you card */}
      <g transform="translate(330,150) rotate(8)">
        <rect x="0" y="0" width="66" height="44" rx="2" fill="#FFFDF8" stroke="#00000014" />
        <line x1="10" y1="16" x2="56" y2="16" stroke="#00000025" strokeWidth="2" />
        <line x1="10" y1="26" x2="42" y2="26" stroke="#00000018" strokeWidth="2" />
      </g>

      {/* receipt on table */}
      <g transform="translate(215,340) rotate(-4)">
        <rect x="0" y="0" width="46" height="60" fill="#FFFDF8" stroke="#00000012" />
        <line x1="8" y1="10" x2="38" y2="10" stroke="#00000018" strokeWidth="1.5" />
        <line x1="8" y1="18" x2="38" y2="18" stroke="#00000012" strokeWidth="1.5" />
        <line x1="8" y1="26" x2="30" y2="26" stroke="#00000012" strokeWidth="1.5" />
        <line x1="8" y1="40" x2="38" y2="40" stroke="#00000018" strokeWidth="1.5" />
      </g>
    </svg>
  );
}
