"use client";

import { Component, useEffect, useRef, useState, useCallback, type ReactNode } from "react";
import dynamic from "next/dynamic";
import { Hero3DFallback } from "./Hero3DFallback";
import { computeHero3DCapability, type Hero3DCapability } from "./capability";

// webpackPrefetch: chunk three.js (~ratusan KB) diunduh saat browser idle
// segera setelah halaman utama siap — saat hero mount, tinggal eksekusi,
// bukan menunggu download.
const Hero3DCanvas = dynamic(() => import(/* webpackPrefetch: true */ "./Hero3DCanvas").then((m) => m.Hero3DCanvas), { ssr: false });

// If anything inside the 3D subtree throws (WebGL context lost, driver
// quirk, a texture failing to build, etc.) we never want a blank hole in
// the hero — fall back to the static illustration permanently for this
// session instead of crashing or leaving an empty canvas.
class Hero3DErrorBoundary extends Component<{ onError: () => void; children: ReactNode }, { hasError: boolean }> {
  state = { hasError: false };
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  componentDidCatch() {
    this.props.onError();
  }
  render() {
    if (this.state.hasError) return null;
    return this.props.children;
  }
}

export function Hero3DScene({ className = "" }: { className?: string }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [capability, setCapability] = useState<Hero3DCapability | null>(null);
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);

  // Drag horizontal user → rotasi Y scene (derajat). Lewat ref supaya
  // tidak memicu re-render per pointermove; dibaca langsung di useFrame.
  const dragRotation = useRef(0);
  const dragState = useRef({ active: false, lastX: 0 });
  // Progress scroll hero (0..1) — dipakai kamera 3D untuk dolly halus.
  const scrollProgress = useRef(0);

  const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!capability || capability.reducedMotion) return;
    dragState.current = { active: true, lastX: e.clientX };
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dragState.current.active) return;
    const dx = e.clientX - dragState.current.lastX;
    dragState.current.lastX = e.clientX;
    // 0.4° per pixel — cukup responsif tanpa jadi joystick. Clamp ±30°.
    dragRotation.current = Math.min(30, Math.max(-30, dragRotation.current + dx * 0.4));
  };

  const endDrag = () => {
    dragState.current.active = false;
  };

  const recompute = useCallback(() => {
    setCapability(computeHero3DCapability());
  }, []);

  useEffect(() => {
    // Baca sinyal capability satu frame setelah paint pertama — menghindari
    // setState sinkron di body effect (cascading render) dan tetap cukup
    // cepat: fallback statis tampil sebentar lalu crossfade ke canvas.
    const raf = requestAnimationFrame(recompute);

    let resizeTimer: ReturnType<typeof setTimeout>;
    const onResize = () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(recompute, 150);
    };

    window.addEventListener("resize", onResize);
    window.addEventListener("orientationchange", recompute);

    const motionQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    motionQuery.addEventListener?.("change", recompute);

    return () => {
      cancelAnimationFrame(raf);
      clearTimeout(resizeTimer);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("orientationchange", recompute);
      motionQuery.removeEventListener?.("change", recompute);
    };
  }, [recompute]);

  // Safety net: if the canvas never confirms it actually rendered a frame
  // within a few seconds (stalled WebGL init, dynamic import failure,
  // silent driver issue), stop waiting and keep the static illustration
  // instead of leaving an empty box on screen.
  useEffect(() => {
    if (!capability || capability.tier === "D" || ready || failed) return;
    const timeout = setTimeout(() => setFailed(true), 4000);
    return () => clearTimeout(timeout);
  }, [capability, ready, failed]);

  // Scroll-out: stays fully visible while the hero is on screen, then eases
  // out only in the final third of the hero's height — not from pixel 1 —
  // so it doesn't feel like it vanishes the moment the user scrolls.
  useEffect(() => {
    if (!capability || capability.tier === "D" || capability.reducedMotion || failed) return;
    const el = containerRef.current;
    if (!el) return;

    let ticking = false;
    const heroSection = el.closest("section");

    const onScroll = () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        const heroHeight = heroSection?.getBoundingClientRect().height ?? window.innerHeight;
        const raw = Math.min(1, Math.max(0, window.scrollY / heroHeight));
        scrollProgress.current = raw;
        // Only start fading after 40% scrolled through the hero.
        const progress = Math.max(0, (raw - 0.4) / 0.6);
        // Tulis style lewat ref langsung — tanpa setState, tanpa re-render
        // React per frame scroll.
        el.style.opacity = String(1 - progress);
        el.style.transform = `scale(${1 - progress * 0.04}) translateY(${progress * 10}px)`;
        ticking = false;
      });
    };

    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [capability, failed]);

  const showStaticOnly = !capability || capability.tier === "D" || failed;

  if (showStaticOnly) {
    return (
      <div className={className}>
        <Hero3DFallback className="w-full h-full" />
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className={`${className} cursor-grab active:cursor-grabbing touch-pan-y select-none`}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={endDrag}
      onPointerCancel={endDrag}
      aria-label="Ilustrasi 3D paket produk UNO Shop yang siap dikirim ke pelanggan — geser untuk memutar"
      role="img"
    >
      {/* Static image underneath — visible until the canvas confirms a real WebGL frame, then crossfades out */}
      <Hero3DFallback className={`absolute inset-0 w-full h-full transition-opacity duration-500 ${ready ? "opacity-0" : "opacity-100"}`} />
      <div className={`absolute inset-0 transition-opacity duration-500 ${ready ? "opacity-100" : "opacity-0"}`}>
        <Hero3DErrorBoundary onError={() => setFailed(true)}>
          <Hero3DCanvas
            key={`${capability.tier}-${capability.cameraDistanceScale}-${Object.values(capability.composition).join("")}`}
            capability={capability}
            dragRotation={dragRotation}
            scrollProgress={scrollProgress}
            onReady={() => setReady(true)}
          />
        </Hero3DErrorBoundary>
      </div>
    </div>
  );
}
