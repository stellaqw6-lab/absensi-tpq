"use client";

/**
 * Studio product-photography lighting: soft warm key from upper-left,
 * a weak fill from the opposite side to lift shadows, and a very subtle
 * rim light to separate the parcel from the background. No bloom, no
 * post-processing — premium look comes from light + material, not glow.
 */
export function Hero3DLighting({ enabled = true }: { enabled?: boolean }) {
  return (
    <>
      {/* Soft ambient base so shadows never go pure black */}
      <ambientLight intensity={0.35} color="#fff4e8" />

      {/* Key light — large soft warm light, upper-left */}
      <directionalLight
        position={[-3.2, 4.5, 3]}
        intensity={1.15}
        color="#fff2df"
        castShadow={enabled}
        shadow-mapSize-width={enabled ? 1024 : 256}
        shadow-mapSize-height={enabled ? 1024 : 256}
        shadow-camera-near={0.5}
        shadow-camera-far={12}
        shadow-camera-left={-3}
        shadow-camera-right={3}
        shadow-camera-top={3}
        shadow-camera-bottom={-3}
        shadow-bias={-0.0015}
      />

      {/* Fill light — weaker, opposite side, no shadow casting */}
      <directionalLight position={[3, 2, 2]} intensity={0.35} color="#eef2ff" />

      {/* Rim / edge light — subtle separation from background */}
      <directionalLight position={[-1, 2, -3.5]} intensity={0.28} color="#ffe9d0" />
    </>
  );
}
