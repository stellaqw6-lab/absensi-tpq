"use client";

export type Tier = "A" | "B" | "C" | "D";

export interface Hero3DComposition {
  showBag: boolean;
  showProduct: boolean;
  showCard: boolean;
  showReceipt: boolean;
}

export interface Hero3DCapability {
  tier: Tier;
  dpr: [number, number];
  shadows: boolean;
  enableParallax: boolean;
  reducedMotion: boolean;
  composition: Hero3DComposition;
  cameraDistanceScale: number; // 1 = default; <1 = camera pulled in closer for small/simple compositions
  environment: "full" | "simple" | "none"; // background set dressing — first thing dropped on weaker devices
}

function supportsWebGL(): boolean {
  try {
    const canvas = document.createElement("canvas");
    return !!(canvas.getContext("webgl2") || canvas.getContext("webgl"));
  } catch {
    return false;
  }
}

interface NetworkInformationLike {
  saveData?: boolean;
  effectiveType?: string;
}

function getConnection(): NetworkInformationLike | undefined {
  return (navigator as unknown as { connection?: NetworkInformationLike }).connection;
}

function getDeviceMemory(): number | undefined {
  return (navigator as unknown as { deviceMemory?: number }).deviceMemory;
}

/**
 * Reads current capability signals and returns a tier + concrete render
 * settings. Call again on resize/orientation change — width affects both
 * layout composition and, combined with hardware signals, the quality tier.
 */
export function computeHero3DCapability(): Hero3DCapability {
  const width = window.innerWidth;
  const height = window.innerHeight;
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const hasFinePointer = window.matchMedia("(pointer: fine)").matches;
  const hasHover = window.matchMedia("(hover: hover)").matches;
  const webgl = supportsWebGL();
  const cores = navigator.hardwareConcurrency ?? 4;
  const memory = getDeviceMemory(); // undefined on browsers that don't expose it (Safari, Firefox)
  const connection = getConnection();
  const saveData = !!connection?.saveData;
  const slowNetwork = connection?.effectiveType === "slow-2g" || connection?.effectiveType === "2g";
  const shortViewport = height > 0 && height < 620;

  // ---- forced fallback (Tier D): nothing here should ever crash or hang ----
  const veryLowEnd = (memory !== undefined && memory <= 2) || cores <= 2;
  if (!webgl || veryLowEnd) {
    return {
      tier: "D",
      dpr: [1, 1],
      shadows: false,
      enableParallax: false,
      reducedMotion: true,
      composition: { showBag: false, showProduct: false, showCard: false, showReceipt: false },
      cameraDistanceScale: 1,
      environment: "none",
    };
  }

  // ---- width bucket (independent of hardware) ----
  const isSmallPhone = width < 375;
  const isPhone = width < 768;
  const isTablet = width >= 768 && width < 1024;
  const isDesktopUp = width >= 1024;

  // ---- hardware-driven base tier ----
  let tier: Tier = "A";
  if (saveData || slowNetwork || cores <= 3) tier = "C";
  else if (cores <= 6 || (memory !== undefined && memory <= 4)) tier = "B";

  // ---- width can only downgrade the tier further, never upgrade a weak device ----
  if (isPhone && tier === "A") tier = "B";
  if (isSmallPhone) tier = "C";

  const composition: Hero3DComposition = isSmallPhone
    ? { showBag: false, showProduct: false, showCard: true, showReceipt: false }
    : isPhone
    ? { showBag: false, showProduct: true, showCard: true, showReceipt: false }
    : isTablet
    ? { showBag: true, showProduct: true, showCard: true, showReceipt: false }
    : { showBag: true, showProduct: true, showCard: true, showReceipt: true };

  const enableParallax = tier === "A" && hasFinePointer && hasHover && !reducedMotion && isDesktopUp;

  const dpr: [number, number] =
    tier === "A" ? [1, 2] : tier === "B" ? [1, 1.5] : [1, 1];

  const shadows = tier !== "C" && !shortViewport;

  // Simpler composition reads better slightly closer to camera.
  const cameraDistanceScale = isSmallPhone ? 0.82 : isPhone ? 0.9 : 1;

  // Background environment is the first thing dropped on weaker devices/screens —
  // main parcel keeps its fallback quality far longer than the backdrop does.
  const environment: Hero3DCapability["environment"] = isPhone || tier === "C" ? "none" : tier === "A" && isDesktopUp ? "full" : "simple";

  return { tier, dpr, shadows, enableParallax, reducedMotion, composition, cameraDistanceScale, environment };
}
