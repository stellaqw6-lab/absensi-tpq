"use client";

import { useRef, useState } from "react";
import { motion, useScroll, useTransform, useMotionValueEvent } from "framer-motion";
import { HandHeart, Package, Home } from "lucide-react";
import { useMotionPrefs } from "@/hooks/use-motion-prefs";
import { durations, easeOutExpo } from "@/lib/motion";

const steps = [
  {
    icon: HandHeart,
    title: "Dibuat dengan tangan lokal",
    text: "Setiap produk lahir dari usaha kecil Indonesia — bukan pabrik massal, tapi tangan pengrajin yang benar-benar mengenal produknya.",
    bg: "bg-amber-50 dark:bg-stone-800",
    ring: "text-amber-600 dark:text-amber-400",
  },
  {
    icon: Package,
    title: "Dikemas dengan cinta",
    text: "Penjual mengemas pesananmu sendiri: rapi, aman, dan kadang ada kartu ucapan terima kasih di dalamnya.",
    bg: "bg-blue-50 dark:bg-stone-800",
    ring: "text-blue-600 dark:text-blue-400",
  },
  {
    icon: Home,
    title: "Sampai di tangan Anda",
    text: "Produk tiba di tangan Anda — transaksi selesai dengan mulus. Selamat menikmati pesanan Anda!",
    bg: "bg-emerald-50 dark:bg-stone-800",
    ring: "text-emerald-600 dark:text-emerald-400",
  },
];

/**
 * Scroll storytelling: panel sticky, langkah cerita berganti mengikuti
 * progres scroll. GPU-only (transform/opacity). Versi reduced-motion /
 * device lemah otomatis render statis tanpa listener scroll.
 */
export function StorySection() {
  const prefs = useMotionPrefs();
  const ref = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end end"],
  });

  useMotionValueEvent(scrollYProgress, "change", (v) => {
    const step = Math.min(steps.length - 1, Math.max(0, Math.floor(v * steps.length)));
    if (step !== active) setActive(step);
  });

  // Rotasi halus panel visual sepanjang section — terasa seperti kamera.
  const visualRotate = useTransform(scrollYProgress, [0, 1], [0, 6]);

  const interactive = prefs.allowMotion;

  // ---- Fallback statis: tanpa sticky, tanpa listener, tetap informatif ----
  if (!interactive) {
    return (
      <section className="border-y border-gray-100 bg-white dark:border-stone-800 dark:bg-stone-950">
        <div className="container mx-auto px-4 py-14">
          <h2 className="text-2xl font-bold text-center text-gray-900 mb-10 dark:text-stone-100">
            Perjalanan satu produk lokal
          </h2>
          <div className="grid gap-6 md:grid-cols-3 max-w-4xl mx-auto">
            {steps.map((step) => (
              <div key={step.title} className="text-center">
                <div className={`mx-auto w-14 h-14 rounded-full ${step.bg} flex items-center justify-center mb-3`}>
                  <step.icon size={24} className={step.ring} />
                </div>
                <h3 className="font-semibold text-gray-900 mb-1 dark:text-stone-100">{step.title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed dark:text-stone-400">{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section ref={ref} className="relative h-[280vh] border-y border-gray-100 bg-white dark:border-stone-800 dark:bg-stone-950">
      <div className="sticky top-0 h-[100svh] flex items-center overflow-hidden">
        <div className="container mx-auto px-4 w-full">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            {/* ---- Visual: tumpukan kartu berganti per langkah ---- */}
            <div className="relative h-64 sm:h-72 mx-auto w-full max-w-sm order-1 lg:order-2">
              <motion.div style={{ rotate: visualRotate }} className="absolute inset-0">
                {steps.map((step, i) => (
                  <motion.div
                    key={step.title}
                    className="absolute inset-0 flex flex-col items-center justify-center rounded-2xl border border-gray-100 shadow-sm dark:border-stone-800"
                    initial={false}
                    animate={{
                      opacity: active === i ? 1 : 0,
                      scale: active === i ? 1 : 0.92,
                      y: active === i ? 0 : 14,
                      zIndex: active === i ? 2 : 1,
                    }}
                    transition={{ duration: durations.slow, ease: easeOutExpo }}
                  >
                    <div className={`w-20 h-20 rounded-full ${step.bg} flex items-center justify-center mb-5`}>
                      <step.icon size={36} className={step.ring} />
                    </div>
                    <p className="text-sm font-medium text-gray-400 dark:text-stone-500">
                      Langkah {i + 1} dari {steps.length}
                    </p>
                  </motion.div>
                ))}
              </motion.div>
            </div>

            {/* ---- Teks langkah aktif + progress ---- */}
            <div className="order-2 lg:order-1">
              <p className="text-sm font-medium text-blue-600 mb-2 dark:text-blue-400">Dari tangan ke tangan</p>
              <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-6 dark:text-stone-100">
                Perjalanan satu produk lokal
              </h2>

              <div className="h-1 w-full max-w-xs bg-gray-100 rounded-full mb-8 overflow-hidden dark:bg-stone-800">
                <motion.div
                  className="h-full bg-blue-600 dark:bg-blue-500 origin-left"
                  style={{ scaleX: scrollYProgress }}
                />
              </div>

              <div className="space-y-5">
                {steps.map((step, i) => (
                  <div
                    key={step.title}
                    className={`transition-opacity duration-300 ${
                      active === i ? "opacity-100" : "opacity-35"
                    }`}
                  >
                    <h3 className="font-semibold text-gray-900 dark:text-stone-100">{step.title}</h3>
                    <p className="text-sm text-gray-500 leading-relaxed mt-1 max-w-md dark:text-stone-400">{step.text}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
