import Link from "next/link";
import {
  Shirt,
  Coffee,
  UtensilsCrossed,
  Gem,
  Scissors,
  Home,
  Package,
  LayoutGrid,
} from "lucide-react";
import type { categories as categoriesTable } from "@/db/schema";

type Category = typeof categoriesTable.$inferSelect;

const iconByName: Record<string, typeof Shirt> = {
  Fashion: Shirt,
  Makanan: UtensilsCrossed,
  Minuman: Coffee,
  Kerajinan: Scissors,
  Aksesoris: Gem,
  Dekorasi: Home,
};

export function CategorySection({ categories }: { categories: Category[] }) {
  if (categories.length === 0) return null;

  return (
    <section className="border-b border-gray-100 bg-white dark:border-stone-800 dark:bg-stone-950">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center gap-1 overflow-x-auto">
          <Link
            href="/produk"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium text-gray-600 hover:bg-gray-100 whitespace-nowrap transition-colors dark:text-stone-300 dark:hover:bg-stone-800"
          >
            <LayoutGrid size={15} />
            Semua
          </Link>
          {categories.map((cat) => {
            const Icon = iconByName[cat.name] ?? Package;
            return (
              <Link
                key={cat.id}
                href={`/produk?kategori=${cat.slug}`}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium text-gray-600 hover:bg-gray-100 whitespace-nowrap transition-colors dark:text-stone-300 dark:hover:bg-stone-800"
              >
                <Icon size={15} />
                {cat.name}
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}
