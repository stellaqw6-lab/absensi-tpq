import { Star } from "lucide-react";
import { RevealText } from "@/components/ui/reveal-text";
import type { testimonials as testimonialsTable } from "@/db/schema";

type Testimonial = typeof testimonialsTable.$inferSelect;

function initials(name: string) {
  return name
    .split(" ")
    .map((n) => n.charAt(0))
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

export function TestimonialSection({ testimonials }: { testimonials: Testimonial[] }) {
  if (testimonials.length === 0) return null;

  return (
    <section className="py-10 border-t border-gray-100 dark:border-stone-800">
      <div className="container mx-auto px-4">
        <RevealText
          text="Kata Pelanggan"
          as="h2"
          className="text-xl font-semibold text-gray-900 mb-6 dark:text-stone-100"
        />

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {testimonials.map((testimonial) => (
            <div
              key={testimonial.id}
              className="border border-gray-200 rounded-lg p-4 dark:border-stone-800"
            >
              <div className="flex items-center gap-0.5 mb-2">
                {Array.from({ length: 5 }).map((_, j) => (
                  <Star
                    key={j}
                    size={13}
                    className={j < testimonial.rating ? "text-amber-500 fill-amber-500" : "text-gray-300 dark:text-stone-700"}
                  />
                ))}
              </div>
              <p className="text-sm text-gray-600 leading-relaxed mb-3 dark:text-stone-400">
                &ldquo;{testimonial.content}&rdquo;
              </p>
              <div className="flex items-center gap-2.5 border-t border-gray-100 pt-3 dark:border-stone-800">
                <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-600 text-xs font-semibold dark:bg-stone-800 dark:text-stone-300">
                  {initials(testimonial.name)}
                </div>
                <div>
                  <p className="font-medium text-gray-900 text-sm dark:text-stone-100">{testimonial.name}</p>
                  <p className="text-xs text-gray-400 dark:text-stone-500">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
