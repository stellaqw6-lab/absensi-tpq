"use client";

import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown } from "lucide-react";
import { useState } from "react";
import { RevealText } from "@/components/ui/reveal-text";
import type { faqs as faqsTable } from "@/db/schema";

type Faq = typeof faqsTable.$inferSelect;

export function FaqSection({ faqs }: { faqs: Faq[] }) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  if (faqs.length === 0) return null;

  return (
    <section className="py-10 border-t border-gray-100 dark:border-stone-800">
      <div className="container mx-auto px-4 max-w-2xl">
        <RevealText
          text="Pertanyaan Umum"
          as="h2"
          className="text-xl font-semibold text-gray-900 mb-6 dark:text-stone-100"
        />

        <div className="border border-gray-200 rounded-lg divide-y divide-gray-200 dark:border-stone-800 dark:divide-stone-800">
          {faqs.map((faq, i) => (
            <div key={faq.id}>
              <button
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="w-full flex items-center justify-between gap-3 px-4 py-3.5 text-left hover:bg-gray-50 transition-colors dark:hover:bg-stone-900"
              >
                <span className="font-medium text-gray-900 text-sm dark:text-stone-100">{faq.question}</span>
                <ChevronDown
                  size={16}
                  className={`text-gray-400 flex-shrink-0 transition-transform dark:text-stone-500 ${
                    openIndex === i ? "rotate-180" : ""
                  }`}
                />
              </button>
              <AnimatePresence initial={false}>
                {openIndex === i && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ type: "spring", stiffness: 320, damping: 32 }}
                    className="overflow-hidden"
                  >
                    <motion.p
                      initial={{ y: -6 }}
                      animate={{ y: 0 }}
                      className="px-4 pb-4 text-sm text-gray-500 leading-relaxed dark:text-stone-400"
                    >
                      {faq.answer}
                    </motion.p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
