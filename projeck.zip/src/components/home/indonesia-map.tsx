"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { useMotionPrefs } from "@/hooks/use-motion-prefs";
import { durations, easeOutExpo } from "@/lib/motion";

/**
 * Peta Indonesia bergaya dot-constellation: siluet nusantara dari titik-titik,
 * tiap pulau satu region interaktif — hover (desktop) / tap (mobile)
 * menyorot pulau + menampilkan namanya. Statis & informatif saat
 * reduced-motion. Sengaja tidak pakai geo-JSON: ringan, ~3KB.
 */

// viewBox 100x56. Tiap pulau: { label, dots[xy], labelPos }
const ISLANDS = [
  {
    label: "Sumatera",
    labelPos: [24, 30] as const,
    dots: [
      [8, 14], [11, 16], [14, 18], [16, 21], [18, 24], [19, 27], [21, 30],
      [22, 33], [24, 36], [26, 38], [29, 39], [13, 13], [17, 19], [15, 24],
      [19, 30], [23, 35], [27, 40], [31, 40], [16, 15], [25, 33],
    ],
  },
  {
    label: "Jawa",
    labelPos: [46, 45] as const,
    dots: [
      [36, 43], [39, 43], [42, 44], [45, 44], [48, 45], [51, 45], [54, 44],
      [57, 43], [60, 42], [63, 41], [41, 45], [47, 46], [53, 46], [58, 42],
    ],
  },
  {
    label: "Kalimantan",
    labelPos: [52, 20] as const,
    dots: [
      [44, 8], [47, 7], [50, 7], [53, 8], [56, 10], [58, 13], [59, 16],
      [58, 19], [56, 22], [53, 24], [50, 25], [47, 24], [45, 21], [44, 17],
      [44, 13], [48, 10], [52, 11], [55, 15], [52, 19], [48, 20], [46, 15],
    ],
  },
  {
    label: "Sulawesi",
    labelPos: [71, 24] as const,
    dots: [
      [67, 8], [69, 10], [70, 13], [71, 16], [72, 19], [74, 21], [77, 23],
      [79, 25], [76, 19], [74, 16], [75, 13], [73, 10], [70, 20], [68, 13],
      [78, 21], [80, 27], [76, 25], [66, 9],
    ],
  },
  {
    label: "Bali & Nusa Tenggara",
    labelPos: [68, 46] as const,
    dots: [
      [64, 46], [67, 47], [70, 48], [73, 48], [76, 47], [79, 46], [82, 45],
      [68, 46], [74, 47], [80, 45],
    ],
  },
  {
    label: "Maluku",
    labelPos: [88, 26] as const,
    dots: [
      [85, 12], [86, 15], [87, 18], [88, 21], [89, 24], [90, 27], [91, 30],
      [86, 20], [89, 15],
    ],
  },
  {
    label: "Papua",
    labelPos: [95, 24] as const,
    dots: [
      [92, 10], [95, 9], [98, 11], [99, 14], [98, 17], [96, 20], [94, 22],
      [93, 25], [95, 13], [97, 18], [96, 24],
    ],
  },
];

export function IndonesiaMap() {
  const prefs = useMotionPrefs();
  const [active, setActive] = useState<string | null>(null);

  return (
    <section className="py-16 border-t border-gray-100 bg-white dark:border-stone-800 dark:bg-stone-950">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-10 items-center">
          <div>
            <p className="text-sm font-medium text-blue-600 mb-2 dark:text-blue-400">Sabang sampai Merauke</p>
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4 dark:text-stone-100">
              Jaringan Toko Nusantara
            </h2>
            <p className="text-gray-500 leading-relaxed mb-6 max-w-md dark:text-stone-400">
              Setiap titik adalah pulau di mana mitra toko kami bertumbuh. Arahkan kursor atau sentuh
              titiknya untuk menjelajah.
            </p>
            <div className="min-h-7">
              {active ? (
                <motion.span
                  key={active}
                  initial={prefs.allowMotion ? { opacity: 0, y: 6 } : false}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: durations.fast, ease: easeOutExpo }}
                  className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-50 text-blue-700 text-sm font-semibold dark:bg-blue-950/40 dark:text-blue-400"
                >
                  <span className="w-2 h-2 rounded-full bg-blue-600 dark:bg-blue-400" />
                  {active}
                </motion.span>
              ) : (
                <span className="text-sm text-gray-400 dark:text-stone-500">— pilih pulau —</span>
              )}
            </div>
          </div>

          <motion.svg
            viewBox="0 0 108 58"
            className="w-full max-w-xl mx-auto"
            role="img"
            aria-label="Peta Indonesia bergaya titik dengan pulau-pulau interaktif"
            initial={prefs.allowMotion ? { opacity: 0, scale: 0.96 } : false}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: durations.slower, ease: easeOutExpo }}
          >
            {ISLANDS.map((island) => {
              const isActive = active === island.label;
              return (
                <g
                  key={island.label}
                  onPointerEnter={() => setActive(island.label)}
                  onPointerDown={() => setActive(island.label)}
                  onPointerLeave={() => setActive(null)}
                  className="cursor-pointer"
                >
                  {island.dots.map(([x, y], i) => (
                    <motion.circle
                      key={i}
                      cx={x}
                      cy={y}
                      r={isActive ? 1.15 : 0.85}
                      className={
                        isActive
                          ? "fill-blue-600 dark:fill-blue-400"
                          : "fill-gray-300 dark:fill-stone-700"
                      }
                      initial={prefs.allowMotion ? { scale: 0 } : false}
                      whileInView={{ scale: 1 }}
                      viewport={{ once: true }}
                      transition={{ duration: durations.slow, delay: i * 0.008, ease: easeOutExpo }}
                      style={{ transformOrigin: `${x}px ${y}px` }}
                    />
                  ))}
                </g>
              );
            })}
          </motion.svg>
        </div>
      </div>
    </section>
  );
}
