"use client";

import { useRef, type ReactNode } from "react";
import { motion } from "framer-motion";
import { ShieldCheck, HandHeart, Wallet, PackageSearch } from "lucide-react";
import { RevealText } from "@/components/ui/reveal-text";
import { staggerContainer, staggerItem } from "@/lib/motion";

function GlowCard({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);

  // Posisi glow ditulis lewat CSS variable — tanpa re-render per gerak kursor.
  const onMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    el.style.setProperty("--mx", `${e.clientX - r.left}px`);
    el.style.setProperty("--my", `${e.clientY - r.top}px`);
  };

  return (
    <motion.div
      ref={ref}
      onPointerMove={onMove}
      variants={staggerItem}
      className={`group relative overflow-hidden rounded-2xl border border-gray-100 bg-white p-6 transition-colors hover:border-gray-200 dark:border-stone-800 dark:bg-stone-900 dark:hover:border-stone-700 ${className}`}
    >
      {/* Spotlight glow mengikuti kursor di dalam kartu */}
      <div
        className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100"
        style={{
          background:
            "radial-gradient(320px circle at var(--mx, 50%) var(--my, 50%), rgba(37,99,235,0.10), transparent 70%)",
        }}
        aria-hidden="true"
      />
      <div className="relative">{children}</div>
    </motion.div>
  );
}

function CardIcon({ icon: Icon }: { icon: typeof ShieldCheck }) {
  return (
    <div className="mb-4 w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center dark:bg-blue-950/40">
      <Icon size={22} className="text-blue-600 dark:text-blue-400" />
    </div>
  );
}

/**
 * Bento grid "kenapa belanja di sini" — glow mengikuti kursor di desktop,
 * di sentuhan tetap rapi (glow hanya muncul saat hover, tak ada di touch).
 */
export function WhyBento() {
  return (
    <section className="py-14">
      <div className="container mx-auto px-4">
        <RevealText
          text="Kenapa Belanja di Sini"
          as="h2"
          className="text-2xl font-bold text-gray-900 mb-2 dark:text-stone-100"
        />
        <p className="text-gray-500 mb-8 max-w-md dark:text-stone-400">
          Bukan sekadar marketplace — setiap transaksi adalah dukungan nyata untuk usaha kecil Indonesia.
        </p>

        <motion.div
          variants={staggerContainer(0.1)}
          initial="initial"
          whileInView="whileInView"
          viewport={{ once: true, margin: "-40px" }}
          className="grid gap-4 md:grid-cols-3"
        >
          <GlowCard className="md:col-span-2">
            <CardIcon icon={HandHeart} />
            <h3 className="font-semibold text-gray-900 mb-1.5 dark:text-stone-100">
              Dana Langsung ke Penjual Lokal
            </h3>
            <p className="text-sm text-gray-500 leading-relaxed dark:text-stone-400">
              Pembayaran kamu diteruskan langsung ke rekening penjual — tanpa perantara yang memotong hasil penjualan.
            </p>
          </GlowCard>

          <GlowCard>
            <CardIcon icon={ShieldCheck} />
            <h3 className="font-semibold text-gray-900 mb-1.5 dark:text-stone-100">Produk Terkurasi</h3>
            <p className="text-sm text-gray-500 leading-relaxed dark:text-stone-400">
              Setiap toko dan produk melewati verifikasi tim kami sebelum tampil.
            </p>
          </GlowCard>

          <GlowCard>
            <CardIcon icon={Wallet} />
            <h3 className="font-semibold text-gray-900 mb-1.5 dark:text-stone-100">Pembayaran Fleksibel</h3>
            <p className="text-sm text-gray-500 leading-relaxed dark:text-stone-400">
              Transfer bank atau e-wallet — pilih yang paling nyaman untukmu.
            </p>
          </GlowCard>

          <GlowCard className="md:col-span-2">
            <CardIcon icon={PackageSearch} />
            <h3 className="font-semibold text-gray-900 mb-1.5 dark:text-stone-100">
              Pengiriman Terlacak Real-Time
            </h3>
            <p className="text-sm text-gray-500 leading-relaxed dark:text-stone-400">
              Pantau perjalanan pesananmu dari tangan penjual sampai depan pintu, dengan resi yang bisa dipercaya.
            </p>
          </GlowCard>
        </motion.div>
      </div>
    </section>
  );
}
