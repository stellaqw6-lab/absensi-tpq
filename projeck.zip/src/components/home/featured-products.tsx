import Link from "next/link";
import { Button } from "@/components/ui/button";
import { RevealText } from "@/components/ui/reveal-text";
import { VelocitySkewGrid } from "@/components/ui/velocity-skew-grid";
import { ProductCard } from "@/components/product/product-card";
import type { ProductCardData } from "@/lib/data";

export function FeaturedProducts({ products }: { products: ProductCardData[] }) {
  if (products.length === 0) return null;

  return (
    <section className="py-10">
      <div className="container mx-auto px-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between mb-6 gap-3">
          <RevealText
            text="Produk Unggulan"
            as="h2"
            className="text-xl font-semibold text-gray-900 dark:text-stone-100"
          />
          <div className="flex gap-2">
            <Link href="/produk?sort=Terpopuler">
              <Button variant="outline" size="sm">Terlaris</Button>
            </Link>
            <Link href="/produk?sort=Terbaru">
              <Button variant="outline" size="sm">Terbaru</Button>
            </Link>
            <Link href="/produk">
              <Button variant="default" size="sm">Lihat Semua</Button>
            </Link>
          </div>
        </div>

        <VelocitySkewGrid>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </VelocitySkewGrid>
      </div>
    </section>
  );
}
