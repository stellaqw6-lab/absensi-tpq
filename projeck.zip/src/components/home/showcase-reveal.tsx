"use client";

import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { useMotionPrefs } from "@/hooks/use-motion-prefs";

export interface ShowcaseItem {
  title: string;
  subtitle: string;
  image: string;
  href: string;
}

/**
 * IMAGE REVEAL — gambar tersingkap dari tengah (clip-path inset mengecil)
 * saat masuk viewport, judul & CTA menyusul dengan sedikit delay.
 * Tidak seperti fade biasa: efek "tirai membuka" terasa disengaja & premium.
 * Reduced-motion: render statis penuh.
 */
function ShowcaseCard({ item, index }: { item: ShowcaseItem; index: number }) {
  const prefs = useMotionPrefs();
  const ref = useRef<HTMLDivElement>(null);

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start 95%", "start 45%"],
  });

  // Inset 50% (garis tengah) → 0 (terbuka penuh).
  const clip = useTransform(scrollYProgress, [0, 1], ["inset(48% 0% 48% 0%)", "inset(0% 0% 0% 0%)"]);
  // Sedikit zoom-out saat terbuka — foto "bernafas".
  const scale = useTransform(scrollYProgress, [0, 1], [1.14, 1]);
  const contentOpacity = useTransform(scrollYProgress, [0.5, 0.9], [0, 1]);
  const contentY = useTransform(scrollYProgress, [0.5, 0.9], [16, 0]);

  const animate = prefs.allowMotion;

  return (
    <motion.div
      ref={ref}
      className="group relative overflow-hidden rounded-2xl border border-gray-100 dark:border-stone-800"
      initial={false}
    >
      <Link href={item.href} className="block">
        <motion.div
          className="aspect-[16/10] overflow-hidden bg-gray-100 dark:bg-stone-800"
          style={animate ? { clipPath: clip } : undefined}
        >
          <motion.img
            src={item.image}
            alt={item.title}
            loading="lazy"
            className="h-full w-full object-cover"
            style={animate ? { scale } : undefined}
          />
        </motion.div>
        <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 via-black/25 to-transparent p-5 pt-16">
          <motion.div style={animate ? { opacity: contentOpacity, y: contentY } : undefined}>
            <p className="text-xs font-semibold uppercase tracking-wider text-blue-200">{item.subtitle}</p>
            <div className="mt-1 flex items-center justify-between">
              <h3 className="text-lg font-bold text-white">{item.title}</h3>
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-white/15 backdrop-blur transition-transform duration-300 group-hover:scale-110">
                <ArrowUpRight size={16} className="text-white" />
              </span>
            </div>
          </motion.div>
        </div>
      </Link>
      <span className="sr-only">{`Etalase ${index + 1}`}</span>
    </motion.div>
  );
}

/**
 * Galeri showcase reveal — dipakai di homepage. Menerima data produk
 * (gambar dari DB) dan menampilkan 3 kartu besar bergaya editorial.
 */
export function ShowcaseReveal({ items }: { items: ShowcaseItem[] }) {
  if (items.length === 0) return null;

  return (
    <section className="py-14">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-bold text-gray-900 mb-8 dark:text-stone-100">Etalase Minggu Ini</h2>
        <div className="grid gap-5 md:grid-cols-3">
          {items.slice(0, 3).map((item, i) => (
            <ShowcaseCard key={item.title + i} item={item} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
