"use client";

import { useRef } from "react";
import { motion, useScroll, useVelocity, useSpring, useMotionValue, useAnimationFrame } from "framer-motion";
import { useMotionPrefs } from "@/hooks/use-motion-prefs";

/**
 * KINETIC TYPOGRAPHY MARQUEE — teks besar berjalan yang "hidup":
 * - Kecepatan & arah dipengaruhi scroll (maju saat scroll ke bawah, mundur
 *   saat ke atas), drift pelan saat diam.
 * - Skew sebanding velocity scroll — teks miring saat cepat, lentur balik.
 * Track digerakkan manual per-frame (useAnimationFrame + motion value),
 * di-wrap modulo supaya loop tanpa batas.
 */
export function KineticMarquee({ text = "Belanja di Toko Lokal • Made in Indonesia •" }: { text?: string }) {
  const prefs = useMotionPrefs();

  const { scrollY } = useScroll();
  const scrollVelocity = useVelocity(scrollY);
  const smoothVelocity = useSpring(scrollVelocity, { stiffness: 120, damping: 34, mass: 0.6 });

  // Posisi track dalam persen (selalu dalam rentang 0..unit agar loop).
  const x = useMotionValue(0);
  const unit = 100 / 3; // 3 salinan → wrap tiap sepertiga.

  useAnimationFrame((_, delta) => {
    if (!prefs.allowMotion) return;
    // Drift dasar (persen per detik) + dorongan velocity scroll.
    const v = smoothVelocity.get();
    const push = Math.max(-1400, Math.min(1400, v)) * 0.02;
    let next = x.get() - (8 + push) * (delta / 1000);
    // Wrap positif.
    next = ((next % unit) + unit) % unit;
    x.set(next);
  });

  // Skew sebanding velocity — ciri khas kinetic type.
  const skewX = useSpring(useTransformClampedVelocity(smoothVelocity), { stiffness: 140, damping: 26 });
  const translateX = useTransformPercent(x);

  if (!prefs.allowMotion) {
    return (
      <div className="overflow-hidden border-y border-gray-100 py-5 dark:border-stone-800" aria-hidden="true">
        <p className="whitespace-nowrap text-center text-2xl font-extrabold tracking-tight text-gray-900 dark:text-stone-100">
          {text}
        </p>
      </div>
    );
  }

  const copies = [0, 1, 2];

  return (
    <div className="overflow-hidden border-y border-gray-100 py-5 select-none dark:border-stone-800" aria-hidden="true">
      <motion.div
        className="flex w-max whitespace-nowrap will-change-transform"
        style={{ x: translateX, skewX }}
      >
        {copies.map((i) => (
          <span
            key={i}
            className="pr-6 text-2xl sm:text-3xl font-extrabold tracking-tight text-gray-900 dark:text-stone-100"
          >
            {text}
            {text}
          </span>
        ))}
      </motion.div>
    </div>
  );
}

// Helper kecil lokal supaya tipe MotionValue eksplisit (hindari any).
import { useTransform, type MotionValue } from "framer-motion";

function useTransformClampedVelocity(v: MotionValue<number>) {
  return useTransform(v, [-2200, 0, 2200], [-7, 0, 7]);
}

function useTransformPercent(x: MotionValue<number>) {
  return useTransform(x, (v) => `-${v}%`);
}
