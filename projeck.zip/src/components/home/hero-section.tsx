"use client";

import { ArrowRight, Shield, Truck, RotateCcw, Sparkles, Star, Package } from "lucide-react";
import Link from "next/link";
import { motion, useMotionValue, useSpring, useMotionTemplate } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Magnetic } from "@/components/ui/magnetic";
import { useMotionPrefs } from "@/hooks/use-motion-prefs";
import { formatCurrency } from "@/lib/utils";
import { Hero3DScene } from "./hero3d/Hero3DScene";

// Chip dekoratif mengambang di sekitar scene 3D — melayang pelan dengan
// durasi berbeda agar tidak sinkron (terasa organik, bukan mesin).
const FLOAT_CHIPS = [
  { icon: Sparkles, text: "100% Produk Lokal", pos: "-left-2 top-8", dur: 5.2, delay: 0 },
  { icon: Star, text: "Kurasi Kualitas", pos: "-right-2 top-[42%]", dur: 6.1, delay: 0.8 },
  { icon: Package, text: "Kirim Se-Indonesia", pos: "left-1/4 -bottom-3", dur: 5.6, delay: 1.6 },
];

export interface HeroSectionProps {
  badgeText?: string;
  titleLine1?: string;
  titleHighlight?: string;
  titleLine2?: string;
  description?: string;
  buttonText?: string;
  buttonUrl?: string;
  previewImage?: string;
  previewProductName?: string;
  previewStoreName?: string | null;
  previewPrice?: number;
}

export function HeroSection({
  badgeText,
  titleLine1 = "Belanja",
  titleHighlight = "Toko Lokal",
  titleLine2 = "Terbaik Indonesia",
  description = "Temukan produk-produk terbaik dari penjual pilihan Indonesia. Kualitas premium dengan harga terjangkau, transaksi mudah dan aman.",
  buttonText = "Jelajahi Produk",
  buttonUrl = "/produk",
  previewImage,
  previewProductName,
  previewStoreName,
  previewPrice,
}: HeroSectionProps) {
  const prefs = useMotionPrefs();

  // ---- Spotlight mengikuti kursor (desktop saja) ----
  const spotX = useMotionValue(50);
  const spotY = useMotionValue(35);
  const sx = useSpring(spotX, { stiffness: 140, damping: 22 });
  const sy = useSpring(spotY, { stiffness: 140, damping: 22 });
  const spotlightBg = useMotionTemplate`radial-gradient(560px circle at ${sx}% ${sy}%, rgba(37,99,235,0.10), transparent 65%)`;
  const spotlightOn = prefs.allowMotion && prefs.finePointer;

  const onSectionMove = (e: React.PointerEvent<HTMLElement>) => {
    if (!spotlightOn) return;
    const rect = e.currentTarget.getBoundingClientRect();
    spotX.set(((e.clientX - rect.left) / rect.width) * 100);
    spotY.set(((e.clientY - rect.top) / rect.height) * 100);
  };

  return (
    <section
      onPointerMove={onSectionMove}
      className="relative overflow-hidden border-b border-gray-100 bg-gray-50/50 dark:border-stone-800 dark:bg-stone-900/40"
    >
      {/* Spotlight halus mengikuti kursor — pointer-events-none supaya
          tidak mengganggu klik/selection. */}
      {spotlightOn && (
        <motion.div
          className="pointer-events-none absolute inset-0 z-0"
          style={{ backgroundImage: spotlightBg }}
          aria-hidden="true"
        />
      )}
      <div className="container relative z-10 py-[clamp(1.5rem,5vh,3.5rem)]">
        <div className="grid lg:grid-cols-[1.3fr_1fr] gap-8 lg:gap-10 items-center">
          {/* Left content */}
          <div>
            {badgeText && (
              <span className="inline-block text-xs font-medium text-blue-700 bg-blue-50 rounded px-2.5 py-1 mb-4 dark:bg-blue-950/40 dark:text-blue-300">
                {badgeText}
              </span>
            )}

            <h1 className="text-[clamp(1.75rem,1.1rem+3vw,2.75rem)] font-bold leading-tight text-gray-900 mb-3 dark:text-stone-100">
              {titleLine1} <span className="text-blue-600 dark:text-blue-400">{titleHighlight}</span> {titleLine2}
            </h1>

            <p className="text-base text-gray-500 mb-6 max-w-md leading-relaxed dark:text-stone-400">
              {description}
            </p>

            <Magnetic className="inline-block">
              <Link href={buttonUrl}>
                <Button variant="premium" size="lg" className="w-full sm:w-auto">
                  {buttonText}
                  <ArrowRight size={18} className="ml-2" />
                </Button>
              </Link>
            </Magnetic>

            <div className="flex flex-wrap items-center gap-x-5 gap-y-2 mt-7">
              {[
                { icon: Shield, label: "100% Original" },
                { icon: Truck, label: "Ongkir Transparan" },
                { icon: RotateCcw, label: "7 Hari Retur" },
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-1.5 text-sm text-gray-500 dark:text-stone-400">
                  <item.icon size={15} className="text-gray-400 dark:text-stone-500" />
                  <span>{item.label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Right: 3D parcel scene — "The Local Parcel" */}
          <div>
            <div className="relative">
              {/* Chip kaca melayang — mati otomatis saat reduced-motion */}
              {prefs.allowMotion &&
                FLOAT_CHIPS.map((chip) => (
                  <motion.div
                    key={chip.text}
                    className={`absolute z-10 ${chip.pos} flex items-center gap-1.5 rounded-full border border-white/60 bg-white/85 px-3 py-1.5 text-xs font-semibold text-gray-700 shadow-md backdrop-blur dark:border-stone-700 dark:bg-stone-900/85 dark:text-stone-200`}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: [0, -6, 0] }}
                    transition={{
                      opacity: { delay: 0.5 + chip.delay * 0.3, duration: 0.5 },
                      y: { duration: chip.dur, repeat: Infinity, ease: "easeInOut", delay: chip.delay },
                    }}
                  >
                    <chip.icon size={13} className="text-blue-600 dark:text-blue-400" />
                    {chip.text}
                  </motion.div>
                ))}
              <Hero3DScene className="relative w-full aspect-[4/3] max-w-md mx-auto lg:mx-0 rounded-lg bg-[#F7F3EC] dark:bg-[#2a241d]" />
            </div>
            {(previewProductName || previewPrice !== undefined) && (
              <Link
                href={buttonUrl}
                className="flex items-center gap-3 mt-4 max-w-md mx-auto lg:mx-0 group"
              >
                {previewImage && (
                  <div className="w-10 h-10 rounded-md overflow-hidden bg-gray-100 flex-shrink-0 dark:bg-stone-800">
                    <img src={previewImage} alt="" className="w-full h-full object-cover" />
                  </div>
                )}
                <div className="min-w-0">
                  {previewProductName && (
                    <p className="text-sm text-gray-700 line-clamp-1 group-hover:text-blue-600 transition-colors dark:text-stone-300">
                      {previewProductName}
                    </p>
                  )}
                  <div className="flex items-center gap-2">
                    {previewStoreName && <span className="text-xs text-gray-400 dark:text-stone-500">{previewStoreName}</span>}
                    {previewPrice !== undefined && (
                      <span className="text-xs font-semibold text-gray-900 dark:text-stone-100">{formatCurrency(previewPrice)}</span>
                    )}
                  </div>
                </div>
              </Link>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
