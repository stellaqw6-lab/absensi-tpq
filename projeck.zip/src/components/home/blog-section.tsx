import Link from "next/link";
import { ArrowRight, Calendar, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { blogPosts as blogPostsTable } from "@/db/schema";

type BlogPost = typeof blogPostsTable.$inferSelect;

function formatDate(date: Date | string | null) {
  if (!date) return "";
  return new Date(date).toLocaleDateString("id-ID", { day: "numeric", month: "short", year: "numeric" });
}

export function BlogSection({ posts }: { posts: BlogPost[] }) {
  if (posts.length === 0) return null;

  return (
    <section className="py-10 border-t border-gray-100 dark:border-stone-800">
      <div className="container mx-auto px-4">
        <div className="flex items-end justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-stone-100">
            Artikel Terbaru
          </h2>
          <Link href="/blog">
            <Button variant="outline" size="sm">
              Lihat Semua
              <ArrowRight size={14} className="ml-1.5" />
            </Button>
          </Link>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {posts.map((post) => (
            <article
              key={post.id}
              className="bg-white rounded-lg border border-gray-200 overflow-hidden hover:border-gray-300 transition-colors group dark:bg-stone-900 dark:border-stone-800"
            >
              <Link href={`/blog/${post.slug}`} className="block relative aspect-[3/2] overflow-hidden">
                <img
                  src={post.coverImage ?? "/placeholder-blog.png"}
                  alt={post.title}
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
                {post.category && <Badge className="absolute top-2 left-2">{post.category}</Badge>}
              </Link>
              <div className="p-4">
                <div className="flex items-center gap-3 text-xs text-gray-400 mb-2 dark:text-stone-500">
                  <span className="flex items-center gap-1">
                    <Calendar size={12} /> {formatDate(post.publishedAt)}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock size={12} /> {Math.max(1, Math.round((post.content?.length ?? 0) / 1000))} min
                  </span>
                </div>
                <Link href={`/blog/${post.slug}`}>
                  <h3 className="font-medium text-gray-900 line-clamp-2 mb-1.5 group-hover:text-blue-600 transition-colors dark:text-stone-100">
                    {post.title}
                  </h3>
                </Link>
                <p className="text-sm text-gray-500 line-clamp-2 dark:text-stone-400">{post.excerpt}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
