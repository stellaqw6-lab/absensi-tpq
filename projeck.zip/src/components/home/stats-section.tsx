"use client";

import type { PlatformStats } from "@/lib/data";
import { AnimatedCounter } from "@/components/ui/animated-counter";

interface StatsSectionProps {
  stats: PlatformStats;
}

export function StatsSection({ stats }: StatsSectionProps) {
  // Semua nilai numerik supaya bisa di-animate AnimatedCounter; suffix ("+")
  // dipisah agar angka menghitung bersih tanpa karakter nyasar.
  const items = [
    stats.storeCount > 0
      ? { value: stats.storeCount, suffix: "+", label: "Toko Bergabung" }
      : null,
    stats.productCount > 0
      ? { value: stats.productCount, suffix: "+", label: "Produk Tersedia" }
      : null,
    stats.customerCount > 0
      ? { value: stats.customerCount, suffix: "+", label: "Pelanggan" }
      : null,
    stats.reviewCount > 0
      ? { value: stats.avgRating, suffix: "", label: `Rating (${stats.reviewCount.toLocaleString("id-ID")} ulasan)`, decimals: 1 }
      : null,
  ].filter((i): i is { value: number; suffix: string; label: string; decimals?: number } => i !== null);

  // Data belum ada sama sekali — jangan tampilkan angka palsu, sembunyikan section.
  if (items.length === 0) return null;

  return (
    <section className="border-y border-gray-100 bg-white dark:border-stone-800 dark:bg-stone-950">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-wrap justify-center gap-x-12 gap-y-6">
          {items.map((item) => (
            <div key={item.label} className="text-center">
              <div className="text-2xl font-bold text-gray-900 dark:text-stone-100 tabular-nums">
                <AnimatedCounter
                  value={item.value}
                  duration={1.6}
                  formatter={(n) =>
                    item.decimals !== undefined
                      ? n.toFixed(item.decimals).replace(".", ",")
                      : Math.round(n).toLocaleString("id-ID")
                  }
                />
                {item.suffix}
              </div>
              <div className="text-sm text-gray-500 dark:text-stone-400">{item.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
