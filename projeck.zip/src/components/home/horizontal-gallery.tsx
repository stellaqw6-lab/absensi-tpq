"use client";

import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { useMotionPrefs } from "@/hooks/use-motion-prefs";

export interface GalleryItem {
  name: string;
  image: string;
  count: number;
  slug: string;
}

/**
 * STICKY PIN + HORIZONTAL SCROLL — section menempel (pin) selama kartu
 * galeri bergulir horizontal mengikuti scroll vertikal. Standar situs
 * award-winning, jarang ada di template. Mobile (layar sempit): fallback
 * scroll-x native dengan snap — tetap mulus di sentuhan.
 */
export function HorizontalGallery({ items }: { items: GalleryItem[] }) {
  const prefs = useMotionPrefs();
  const sectionRef = useRef<HTMLDivElement>(null);

  const { scrollYProgress } = useScroll({ target: sectionRef });
  // Geser track ke kiri sepanjang scroll section. Lebar track ~ kartu × 60vw.
  const x = useTransform(scrollYProgress, [0, 1], ["2%", "-72%"]);
  const trackOpacity = useTransform(scrollYProgress, [0, 0.06, 0.94, 1], [0.5, 1, 1, 0.5]);

  if (items.length === 0) return null;

  // ---- Mobile / reduced-motion: scroll-x native + snap ----
  if (!prefs.allowMotion || typeof window === "undefined" || window.innerWidth < 1024) {
    return (
      <section className="py-14 border-t border-gray-100 dark:border-stone-800">
        <div className="container mx-auto px-4 mb-6">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-stone-100">Jelajah per Kategori</h2>
          <p className="text-sm text-gray-500 mt-1 dark:text-stone-400">Geser ke samping untuk menjelajah</p>
        </div>
        <div className="flex gap-4 overflow-x-auto px-4 pb-4 snap-x snap-mandatory [-ms-overflow-style:none] [scrollbar-width:thin]">
          {items.map((item) => (
            <Link
              key={item.slug}
              href={`/produk?kategori=${item.slug}`}
              className="group relative w-64 flex-shrink-0 snap-center overflow-hidden rounded-2xl border border-gray-100 dark:border-stone-800"
            >
              <div className="aspect-[3/4] bg-gray-100 dark:bg-stone-800">
                <img src={item.image} alt={item.name} loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
              </div>
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent p-4 pt-12">
                <h3 className="font-bold text-white">{item.name}</h3>
                <p className="text-xs text-white/70">{item.count} produk</p>
              </div>
            </Link>
          ))}
        </div>
      </section>
    );
  }

  // ---- Desktop: pin + scroll horizontal ----
  return (
    <section ref={sectionRef} className="relative h-[320vh] border-t border-gray-100 dark:border-stone-800">
      <div className="sticky top-0 flex h-screen flex-col justify-center overflow-hidden">
        <div className="container mx-auto px-4 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-stone-100">Jelajah per Kategori</h2>
          <p className="text-sm text-gray-500 mt-1 dark:text-stone-400">Terus scroll — galeri bergerak menyamping</p>
        </div>

        <motion.div className="flex gap-6 pl-[8vw] will-change-transform" style={{ x, opacity: trackOpacity }}>
          {items.map((item, i) => (
            <motion.div
              key={item.slug}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.06, duration: 0.5 }}
            >
              <Link
                href={`/produk?kategori=${item.slug}`}
                className="group relative block w-[24vw] min-w-[260px] overflow-hidden rounded-2xl border border-gray-100 dark:border-stone-800"
              >
                <div className="aspect-[3/4] bg-gray-100 dark:bg-stone-800">
                  <img src={item.image} alt={item.name} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                </div>
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent p-5 pt-14">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-bold text-white">{item.name}</h3>
                      <p className="text-xs text-white/70">{item.count} produk</p>
                    </div>
                    <span className="flex h-9 w-9 items-center justify-center rounded-full bg-white/15 backdrop-blur transition-transform duration-300 group-hover:scale-110">
                      <ArrowUpRight size={16} className="text-white" />
                    </span>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
