import Link from "next/link";
import { Button } from "@/components/ui/button";

export function CtaSection() {
  return (
    <section className="py-12 border-t border-gray-100 bg-gray-50/50 dark:border-stone-800 dark:bg-stone-900/40">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2 dark:text-stone-100">
          Temukan produk lokal berikutnya
        </h2>
        <p className="text-gray-500 mb-6 dark:text-stone-400">
          Ribuan produk berkualitas menunggu untuk dijelajahi.
        </p>
        <Link href="/produk">
          <Button variant="premium" size="lg">Jelajahi Produk</Button>
        </Link>
      </div>
    </section>
  );
}
