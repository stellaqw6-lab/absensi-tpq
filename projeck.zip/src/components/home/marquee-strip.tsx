import {
  Shirt,
  Coffee,
  UtensilsCrossed,
  Gem,
  Scissors,
  Home,
  Package,
} from "lucide-react";
import type { categories as categoriesTable } from "@/db/schema";

type Category = typeof categoriesTable.$inferSelect;

const iconByName: Record<string, typeof Shirt> = {
  Fashion: Shirt,
  Makanan: UtensilsCrossed,
  Minuman: Coffee,
  Kerajinan: Scissors,
  Aksesoris: Gem,
  Dekorasi: Home,
};

/**
 * Strip marquee nama kategori — CSS murni (tanpa JS), duplikat list agar
 * loop mulus. Pause saat hover (desktop), otomatis mati saat
 * prefers-reduced-motion lewat guard di globals.css.
 */
export function MarqueeStrip({ categories }: { categories: Category[] }) {
  if (categories.length === 0) return null;

  const items = categories.map((cat) => ({
    name: cat.name,
    Icon: iconByName[cat.name] ?? Package,
  }));

  return (
    <div
      className="marquee-paused border-b border-gray-100 bg-white py-3 overflow-hidden dark:border-stone-800 dark:bg-stone-950"
      aria-label="Kategori produk"
    >
      <div
        className="animate-marquee flex w-max items-center gap-10 pr-10 will-change-transform"
        style={{ animationDuration: "30s" }}
      >
        {items.map((item) => (
          <span
            key={item.name}
            className="flex items-center gap-2 text-sm font-medium text-gray-400 dark:text-stone-500"
          >
            <item.Icon size={15} />
            {item.name}
          </span>
        ))}
        {/* Duplikat aria-hidden — murni visual untuk loop tanpa putus */}
        {items.map((item) => (
          <span
            key={`dup-${item.name}`}
            aria-hidden="true"
            className="flex items-center gap-2 text-sm font-medium text-gray-400 dark:text-stone-500"
          >
            <item.Icon size={15} />
            {item.name}
          </span>
        ))}
      </div>
    </div>
  );
}
