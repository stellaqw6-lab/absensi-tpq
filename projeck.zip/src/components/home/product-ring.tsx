"use client";

import { useMemo, useRef, useState, useEffect } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";
import Link from "next/link";
import { useMotionPrefs } from "@/hooks/use-motion-prefs";
import { useDragRotation } from "@/hooks/use-drag-rotation";

export interface RingProduct {
  name: string;
  image: string;
  price: number;
  slug: string;
}

/** Posisi kartu pada ring: sudut merata di lingkaran radius R. */
function ringPosition(i: number, total: number, radius: number) {
  const angle = (i / total) * Math.PI * 2;
  return {
    x: Math.sin(angle) * radius,
    z: Math.cos(angle) * radius,
    angle,
  };
}

function RingCard({
  product,
  index,
  total,
  radius,
  frontAngle,
  texture,
}: {
  product: RingProduct;
  index: number;
  total: number;
  radius: number;
  frontAngle: { current: number };
  texture: THREE.Texture | null;
}) {
  const groupRef = useRef<THREE.Group>(null);

  useFrame(() => {
    if (!groupRef.current) return;
    const { x, z, angle } = ringPosition(index, total, radius);
    // Rotasi ring: posisi kartu berputar mengikuti frontAngle.
    const a = angle + frontAngle.current;
    const px = Math.sin(a) * radius;
    const pz = Math.cos(a) * radius;
    groupRef.current.position.set(px, 0, pz);
    // Kartu selalu menghadap keluar dari ring.
    groupRef.current.rotation.y = a;
  });

  return (
    <group ref={groupRef}>
      {/* Bingkai kartu */}
      <mesh castShadow>
        <boxGeometry args={[1.35, 1.8, 0.05]} />
        <meshStandardMaterial color="#ffffff" roughness={0.6} />
      </mesh>
      {/* Foto produk */}
      <mesh position={[0, 0.09, 0.032]}>
        <planeGeometry args={[1.2, 1.2]} />
        {texture ? (
          <meshStandardMaterial map={texture} roughness={0.7} />
        ) : (
          <meshStandardMaterial color="#e5e7eb" roughness={0.8} />
        )}
      </mesh>
      {/* Pita nama bawah */}
      <mesh position={[0, -0.72, 0.032]}>
        <planeGeometry args={[1.2, 0.42]} />
        <meshStandardMaterial color="#1e293b" roughness={0.5} />
      </mesh>
    </group>
  );
}

/** Hook kecil: sudut ring yang di-drag user (derajat → radian, damped di frame). */
function useFrontAngle(dragRotation: { current: number }) {
  const ref = useRef(0);
  useFrame((_, delta) => {
    const target = THREE.MathUtils.degToRad(dragRotation.current);
    ref.current = THREE.MathUtils.damp(ref.current, target, 5, delta || 0.016);
  });
  return ref;
}

function RingScene({ products, dragRotation }: { products: RingProduct[]; dragRotation: { current: number } }) {
  const frontAngle = useFrontAngle(dragRotation);
  const total = products.length;

  // Muat tekstur foto produk sekali (async, non-blocking).
  const [textures, setTextures] = useState<(THREE.Texture | null)[]>(() => products.map(() => null));
  useEffect(() => {
    let alive = true;
    const loader = new THREE.TextureLoader();
    const loaded: (THREE.Texture | null)[] = products.map(() => null);
    products.forEach((p, i) => {
      loader.load(p.image, (tex) => {
        tex.colorSpace = THREE.SRGBColorSpace;
        tex.anisotropy = 4;
        if (!alive) return;
        loaded[i] = tex;
        setTextures([...loaded]);
      });
    });
    return () => {
      alive = false;
    };
  }, [products]);

  return (
    <>
      <ambientLight intensity={0.75} color="#ffffff" />
      <directionalLight position={[3, 5, 4]} intensity={1.1} />
      <directionalLight position={[-4, 2, -3]} intensity={0.3} color="#c7d2fe" />
      {products.map((p, i) => (
        <RingCard
          key={p.slug + i}
          product={p}
          index={i}
          total={total}
          radius={3.1}
          frontAngle={frontAngle}
          texture={textures[i]}
        />
      ))}
      {/* Lantai bayangan */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.15, 0]} receiveShadow>
        <circleGeometry args={[5, 32]} />
        <shadowMaterial opacity={0.12} />
      </mesh>
    </>
  );
}

/**
 * PRODUCT RING CAROUSEL 3D — kartu produk tersusun melingkar di ruang 3D;
 * geser (drag sentuh/kursor) untuk memutar ring. Kartu paling depan
 * ditampilkan sebagai info aktif. Ini pola yang sangat jarang dipakai
 * template karena butuh komposisi 3D asli, bukan slider CSS.
 */
export function ProductRing({ products }: { products: RingProduct[] }) {
  const prefs = useMotionPrefs();
  const { rotation, handlers } = useDragRotation({ sensitivity: 0.35, axis: "x" });
  const [activeIndex, setActiveIndex] = useState(0);

  // Produk paling depan = yang sudutnya paling mendekati 0 (menghadap kamera).
  // Poll ringan (interval, bukan setState sinkron di effect) supaya label
  // aktif ikut drag tanpa re-render per frame.
  useEffect(() => {
    const id = setInterval(() => {
      if (products.length === 0) return;
      const step = 360 / products.length;
      const idx = Math.round(((-rotation.current % 360) + 360) % 360 / step) % products.length;
      setActiveIndex((prev) => (prev === idx ? prev : idx));
    }, 120);
    return () => clearInterval(id);
  }, [products.length]);

  const visible = products.slice(0, 8);
  const active = visible[activeIndex];

  if (visible.length < 3 || !prefs.allowMotion) {
    // Fallback: grid kecil biasa (juga dipakai reduced-motion / low-end).
    return (
      <section className="py-14 border-t border-gray-100 dark:border-stone-800">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 dark:text-stone-100">Putar Etalase</h2>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {visible.map((p) => (
              <Link key={p.slug} href={`/produk/${p.slug}`} className="group overflow-hidden rounded-xl border border-gray-100 dark:border-stone-800">
                <div className="aspect-square bg-gray-100 dark:bg-stone-800">
                  <img src={p.image} alt={p.name} loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                </div>
                <p className="truncate p-2 text-xs font-medium text-gray-700 dark:text-stone-300">{p.name}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="border-t border-gray-100 py-14 dark:border-stone-800">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-stone-100">Putar Etalase</h2>
        <p className="text-sm text-gray-500 mt-1 mb-6 dark:text-stone-400">
          Geser untuk memutar — produk lain menyusul di belakang
        </p>

        <div
          className="relative h-[380px] sm:h-[420px] cursor-grab active:cursor-grabbing touch-pan-y select-none rounded-2xl bg-gradient-to-b from-gray-50 to-white dark:from-stone-900 dark:to-stone-950"
          {...handlers}
        >
          <Canvas
            shadows
            dpr={[1, 1.5]}
            gl={{ antialias: true, alpha: true }}
            camera={{ position: [0, 0.6, 6.2], fov: 42 }}
          >
            <RingScene products={visible} dragRotation={rotation} />
          </Canvas>

          {/* Info produk aktif di bawah ring */}
          {active && (
            <Link
              href={`/produk/${active.slug}`}
              className="absolute inset-x-0 bottom-4 mx-auto flex w-fit items-center gap-3 rounded-full border border-gray-100 bg-white/90 px-4 py-2 shadow-sm backdrop-blur dark:border-stone-800 dark:bg-stone-900/90"
            >
              <img src={active.image} alt="" className="h-8 w-8 rounded-full object-cover" />
              <span className="max-w-[180px] truncate text-sm font-semibold text-gray-900 dark:text-stone-100">
                {active.name}
              </span>
              <span className="text-xs text-gray-400 dark:text-stone-500">
                {activeIndex + 1}/{visible.length}
              </span>
            </Link>
          )}
        </div>
      </div>
    </section>
  );
}
