"use client";

import Link from "next/link";
import { useRef } from "react";
import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { Star, Heart, ShoppingCart } from "lucide-react";
import { formatCurrency } from "@/lib/utils";
import { useCart } from "@/contexts/cart-context";
import { useWishlist } from "@/contexts/wishlist-context";
import { useMotionPrefs } from "@/hooks/use-motion-prefs";
import { HeartBurstView, useHeartBurst } from "@/components/ui/heart-burst";
import type { ProductCardData } from "@/lib/data";
import toast from "react-hot-toast";

/** Cari ikon keranjang yang sedang terlihat (header desktop / bottom nav mobile). */
function findVisibleCartIcon(): HTMLElement | null {
  const candidates = Array.from(document.querySelectorAll<HTMLElement>("[data-cart-icon]"));
  const visible = candidates.filter((el) => {
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.top >= 0 && rect.bottom <= window.innerHeight;
  });
  return visible[0] ?? candidates[0] ?? null;
}

export function ProductCard({ product }: { product: ProductCardData; index?: number }) {
  const { addItem } = useCart();
  const { productIds, toggle } = useWishlist();
  const prefs = useMotionPrefs();
  const liked = productIds.has(product.id);
  const imgRef = useRef<HTMLImageElement>(null);
  const { bursts, trigger } = useHeartBurst();

  // ---- Tilt 3D halus (hanya pointer presis + motion diizinkan) ----
  const mx = useMotionValue(0.5);
  const my = useMotionValue(0.5);
  const rotateX = useSpring(useTransform(my, [0, 1], [4, -4]), { stiffness: 200, damping: 22 });
  const rotateY = useSpring(useTransform(mx, [0, 1], [-4, 4]), { stiffness: 200, damping: 22 });
  const tiltEnabled = prefs.allowMotion && prefs.finePointer;

  const onTiltMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!tiltEnabled) return;
    const rect = e.currentTarget.getBoundingClientRect();
    mx.set((e.clientX - rect.left) / rect.width);
    my.set((e.clientY - rect.top) / rect.height);
  };
  const resetTilt = () => {
    mx.set(0.5);
    my.set(0.5);
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (product.stock <= 0) {
      toast.error("Stok produk habis");
      return;
    }
    addItem({
      productId: product.id,
      slug: product.slug,
      name: product.name,
      price: product.price,
      image: product.image,
      stock: product.stock,
      sellerId: product.sellerId,
      shippingCost: product.shippingCost,
    });
    toast.success(`${product.name} ditambahkan ke keranjang`);

    // ---- Fly-to-cart: klon gambar terbang ke ikon keranjang ----
    if (prefs.allowMotion && imgRef.current) {
      const img = imgRef.current;
      const cartIcon = findVisibleCartIcon();
      if (!cartIcon) return;
      const from = img.getBoundingClientRect();
      const to = cartIcon.getBoundingClientRect();

      const ghost = img.cloneNode() as HTMLImageElement;
      ghost.className = img.className;
      Object.assign(ghost.style, {
        position: "fixed",
        left: `${from.left}px`,
        top: `${from.top}px`,
        width: `${from.width}px`,
        height: `${from.height}px`,
        borderRadius: "8px",
        zIndex: "80",
        pointerEvents: "none",
        objectFit: "cover",
      });
      document.body.appendChild(ghost);

      const dx = to.left + to.width / 2 - (from.left + from.width / 2);
      const dy = to.top + to.height / 2 - (from.top + from.height / 2);
      const anim = ghost.animate(
        [
          { transform: "translate(0,0) scale(1)", opacity: 1 },
          {
            transform: `translate(${dx}px, ${dy}px) scale(0.1)`,
            opacity: 0.3,
          },
        ],
        { duration: 600, easing: "cubic-bezier(0.22, 1, 0.36, 1)" }
      );
      anim.onfinish = () => ghost.remove();
      anim.oncancel = () => ghost.remove();
    }
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const willLike = !liked;
    toggle(product.id);
    if (willLike) trigger();
  };

  // Maksimal satu badge: prioritaskan diskon, lalu best seller, lalu baru.
  const badge = product.discount > 0
    ? { text: `-${product.discount}%`, className: "bg-red-600 text-white" }
    : product.isBestSeller
    ? { text: "Terlaris", className: "bg-amber-500 text-white" }
    : product.isNew
    ? { text: "Baru", className: "bg-gray-900 text-white dark:bg-stone-100 dark:text-stone-900" }
    : null;

  return (
    <motion.div
      className="group"
      style={tiltEnabled ? { rotateX, rotateY, transformPerspective: 800 } : undefined}
      onPointerMove={onTiltMove}
      onPointerLeave={resetTilt}
    >
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden hover:border-gray-300 hover:shadow-sm transition-colors dark:bg-stone-900 dark:border-stone-800 dark:hover:border-stone-700">
        <Link href={`/produk/${product.slug}`} className="block relative aspect-square overflow-hidden bg-gray-100 dark:bg-stone-800">
          <img
            ref={imgRef}
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-300"
            loading="lazy"
          />
          {badge && (
            <span className={`absolute top-2 left-2 text-[11px] font-semibold px-2 py-0.5 rounded ${badge.className}`}>
              {badge.text}
            </span>
          )}
          {product.stock <= 0 && (
            <div className="absolute inset-0 bg-white/80 flex items-center justify-center dark:bg-stone-950/80">
              <span className="text-xs font-medium text-gray-600 dark:text-stone-300">Stok Habis</span>
            </div>
          )}
          <button
            onClick={handleWishlist}
            aria-label={liked ? "Hapus dari wishlist" : "Tambah ke wishlist"}
            className={`absolute top-2 right-2 p-1.5 rounded-full bg-white/90 shadow-sm dark:bg-stone-900/90 ${
              liked ? "text-red-500" : "text-gray-500 hover:text-red-500 dark:text-stone-400"
            }`}
          >
            <Heart size={15} fill={liked ? "currentColor" : "none"} />
            <HeartBurstView bursts={bursts} />
          </button>
        </Link>

        <div className="p-3">
          <Link href={`/produk/${product.slug}`}>
            <h3 className="text-sm text-gray-900 line-clamp-2 leading-snug dark:text-stone-100">
              {product.name}
            </h3>
          </Link>
          {product.storeName && (
            <p className="text-xs text-gray-400 mt-0.5 line-clamp-1 dark:text-stone-500">{product.storeName}</p>
          )}
          <div className="flex items-center gap-1 mt-1.5">
            <Star size={12} className="text-amber-500 fill-amber-500" />
            <span className="text-xs font-medium text-gray-700 dark:text-stone-300">{product.rating.toFixed(1)}</span>
            <span className="text-xs text-gray-400 dark:text-stone-500">({product.reviewCount})</span>
          </div>
          <div className="flex items-baseline gap-1.5 mt-1.5">
            <span className="font-semibold text-gray-900 dark:text-stone-100">{formatCurrency(product.price)}</span>
            {product.compareAtPrice && (
              <span className="text-xs text-gray-400 line-through dark:text-stone-500">{formatCurrency(product.compareAtPrice)}</span>
            )}
          </div>
          <button
            onClick={handleAddToCart}
            disabled={product.stock <= 0}
            className="mt-3 w-full flex items-center justify-center gap-1.5 text-sm font-medium border border-gray-200 rounded-md py-1.5 text-gray-700 hover:bg-gray-50 hover:border-gray-300 disabled:opacity-40 disabled:cursor-not-allowed transition-colors dark:border-stone-700 dark:text-stone-300 dark:hover:bg-stone-800"
          >
            <ShoppingCart size={14} />
            Keranjang
          </button>
        </div>
      </div>
    </motion.div>
  );
}
