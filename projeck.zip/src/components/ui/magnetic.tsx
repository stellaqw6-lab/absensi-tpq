"use client";

import { useRef, type ReactNode, type PointerEvent as ReactPointerEvent } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";
import { useMotionPrefs } from "@/hooks/use-motion-prefs";

interface MagneticProps {
  children: ReactNode;
  /** 0–1: seberapa jauh elemen tertarik ke kursor (default 0.25). */
  strength?: number;
  /** Batas geser maksimum dalam px (default 10). */
  maxOffset?: number;
  className?: string;
}

/**
 * Efek magnetik: elemen tertarik halus ke arah kursor lalu memantul pulang
 * saat kursor pergi (spring). Hanya aktif di desktop (pointer presis +
 * hover) dan saat motion diizinkan — di touch device render biasa, karena
 * efek magnetik tidak ada artinya tanpa kursor.
 */
export function Magnetic({ children, strength = 0.25, maxOffset = 10, className }: MagneticProps) {
  const prefs = useMotionPrefs();
  const ref = useRef<HTMLDivElement>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const springX = useSpring(x, { stiffness: 260, damping: 18, mass: 0.6 });
  const springY = useSpring(y, { stiffness: 260, damping: 18, mass: 0.6 });

  const enabled = prefs.allowMotion && prefs.finePointer;

  const onPointerMove = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (!enabled || !ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const relX = e.clientX - (rect.left + rect.width / 2);
    const relY = e.clientY - (rect.top + rect.height / 2);
    x.set(Math.max(-maxOffset, Math.min(maxOffset, relX * strength)));
    y.set(Math.max(-maxOffset, Math.min(maxOffset, relY * strength)));
  };

  const reset = () => {
    x.set(0);
    y.set(0);
  };

  if (!enabled) {
    return <div className={className}>{children}</div>;
  }

  return (
    <motion.div
      ref={ref}
      className={className}
      style={{ x: springX, y: springY }}
      onPointerMove={onPointerMove}
      onPointerLeave={reset}
    >
      {children}
    </motion.div>
  );
}
