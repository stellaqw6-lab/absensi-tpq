"use client";

import { useEffect, useRef } from "react";
import { useMotionPrefs } from "@/hooks/use-motion-prefs";

interface ConfettiPiece {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  rot: number;
  vr: number;
  color: string;
  shape: 0 | 1;
}

const COLORS = ["#2563eb", "#7c3aed", "#f59e0b", "#10b981", "#ef4444", "#3b82f6"];

/**
 * Confetti canvas ringan (tanpa dependency) — burst sekali saat mount lalu
 * canvas dibersihkan. ~80 partikel, hanya rAF + rect fill: murah di mobile.
 * Reduced-motion: tidak render sama sekali.
 */
export function Confetti({ count = 80 }: { count?: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const prefs = useMotionPrefs();

  useEffect(() => {
    if (!prefs.allowMotion) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const resize = () => {
      canvas.width = canvas.offsetWidth * dpr;
      canvas.height = canvas.offsetHeight * dpr;
    };
    resize();
    window.addEventListener("resize", resize);

    // Titik asal: dua "meriam" di kiri-bawah & kanan-bawah area atas halaman.
    const w = () => canvas.width;
    const pieces: ConfettiPiece[] = Array.from({ length: count }, (_, i) => {
      const fromLeft = i % 2 === 0;
      const originX = fromLeft ? w() * 0.12 : w() * 0.88;
      const angle = (fromLeft ? -Math.PI / 3 : -Math.PI / 6) + (Math.random() - 0.5) * 0.5;
      const speed = (9 + Math.random() * 5) * dpr;
      return {
        x: originX,
        y: canvas.height * 0.55,
        vx: Math.cos(angle) * speed * (fromLeft ? 1 : 1),
        vy: Math.sin(angle) * speed,
        size: (4 + Math.random() * 4) * dpr,
        rot: Math.random() * Math.PI * 2,
        vr: (Math.random() - 0.5) * 0.3,
        color: COLORS[Math.floor(Math.random() * COLORS.length)],
        shape: (Math.random() > 0.5 ? 1 : 0) as 0 | 1,
      };
    });

    let raf = 0;
    let frames = 0;
    const gravity = 0.35 * dpr;
    const drag = 0.985;

    const tick = () => {
      frames++;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      let alive = false;

      for (const p of pieces) {
        p.vy += gravity;
        p.vx *= drag;
        p.vy *= drag;
        p.x += p.vx;
        p.y += p.vy;
        p.rot += p.vr;

        // Fade out di paruh akhir supaya tidak menghilang mendadak.
        const life = 1 - frames / 150;
        if (life <= 0) continue;
        alive = frames < 150 && p.y < canvas.height + 40 * dpr;

        ctx.save();
        ctx.globalAlpha = Math.max(0, Math.min(1, life * 1.5));
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.fillStyle = p.color;
        if (p.shape) {
          ctx.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2);
        } else {
          ctx.beginPath();
          ctx.arc(0, 0, p.size / 2, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      }

      if (alive && frames < 150) {
        raf = requestAnimationFrame(tick);
      } else {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
      }
    };
    raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, [prefs.allowMotion, count]);

  if (!prefs.allowMotion) return null;

  return (
    <canvas
      ref={canvasRef}
      className="pointer-events-none fixed inset-0 z-[60] w-full h-full"
      aria-hidden="true"
    />
  );
}
