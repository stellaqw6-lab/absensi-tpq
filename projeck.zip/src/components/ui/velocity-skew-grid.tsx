"use client";

import { useRef } from "react";
import { motion, useScroll, useVelocity, useSpring, useTransform } from "framer-motion";
import { useMotionPrefs } from "@/hooks/use-motion-prefs";
import type { ReactNode } from "react";

/**
 * SCROLL VELOCITY SKEW — anak-anak grid miring sebanding kecepatan scroll
 * lalu snap balik lentur saat berhenti. Feedback "fisikal" langka:
 * grid terasa punya massa, bukan gambar mati. GPU-only (skew transform).
 * Dipakai sebagai pembungkus grid produk unggulan.
 */
export function VelocitySkewGrid({ children }: { children: ReactNode }) {
  const prefs = useMotionPrefs();
  const ref = useRef<HTMLDivElement>(null);

  const { scrollY } = useScroll();
  const velocity = useVelocity(scrollY);
  const smooth = useSpring(velocity, { stiffness: 160, damping: 32, mass: 0.5 });

  // Clamp: scroll sangat cepat max ±4.5° — cukup terasa, tidak berlebihan.
  const skewY = useTransform(smooth, [-2600, 0, 2600], [-4.5, 0, 4.5]);

  if (!prefs.allowMotion) {
    return <div ref={ref}>{children}</div>;
  }

  return (
    <motion.div ref={ref} style={{ skewY }} className="will-change-transform">
      {children}
    </motion.div>
  );
}
