"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";
import { motion } from "framer-motion";
import { ShoppingBag } from "lucide-react";

const SESSION_KEY = "umkm-splash-shown";
const PHASE_3D = 3400; // durasi show 3D (biar cukup dinikmati)
const FADE_MS = 500;

type Step = "show" | "fading" | "gone";

/** Label kemajuan yang berganti mengikuti progress bar. */
const STAGES = [
  { at: 0, label: "Menyiapkan etalase..." },
  { at: 0.28, label: "Memuat produk pilihan..." },
  { at: 0.55, label: "Menyapa penjual lokal..." },
  { at: 0.8, label: "Hampir siap..." },
];

// ---- Scene 3D -----------------------------------------------------------

function ParcelScene({ reducedMotion }: { reducedMotion: boolean }) {
  const groupRef = useRef<THREE.Group>(null);
  const boxRef = useRef<THREE.Group>(null);
  const lidRef = useRef<THREE.Group>(null);
  const startTime = useRef<number | null>(null);

  const seg = 4;
  const boxGeo = useMemo(() => new RoundedBoxGeometry(1.7, 1.05, 1.15, seg, 0.035), [seg]);
  const lidGeo = useMemo(() => new RoundedBoxGeometry(1.78, 0.16, 1.22, seg, 0.03), [seg]);
  const paperGeo = useMemo(() => new RoundedBoxGeometry(1.5, 0.5, 1.0, seg, 0.02), [seg]);

  // Kartu "terima kasih" kecil yang muncul dari kotak.
  const cardTex = useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 256;
    canvas.height = 160;
    const ctx = canvas.getContext("2d");
    if (ctx) {
      ctx.fillStyle = "#fffdf8";
      ctx.fillRect(0, 0, 256, 160);
      ctx.fillStyle = "#2b2118";
      ctx.font = "italic 20px Georgia, serif";
      ctx.fillText("Terima kasih", 40, 70);
      ctx.fillText("mendukung lokal.", 40, 98);
    }
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    return texture;
  }, []);

  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    if (startTime.current === null) startTime.current = t;
    const local = t - startTime.current;

    // Tidak ada animasi sama sekali untuk reduced-motion — statis saja.
    if (reducedMotion) return;

    const T = PHASE_3D / 1000;

    // ---- Keseluruhan grup: rotasi presentasi sinematik satu putaran penuh
    // (mundur sedikit di akhir), plus dolly-in halus. ----
    if (groupRef.current) {
      const spin = local / T;
      const ease = 1 - Math.pow(1 - Math.min(1, spin), 3); // easeOutCubic
      groupRef.current.rotation.y = ease * Math.PI * 2;
      const dolly = THREE.MathUtils.lerp(0.5, 0, Math.min(1, local / (T * 0.45)));
      groupRef.current.position.z = dolly;
    }

    // ---- tutup kotak terangkat sejak awal, goyang pelan ----
    if (lidRef.current) {
      const lift = Math.min(1, local / 0.9);
      lidRef.current.position.y = THREE.MathUtils.lerp(0.56, 1.05, lift);
      lidRef.current.rotation.z = THREE.MathUtils.lerp(0, 0.22, lift);
      lidRef.current.rotation.x = Math.sin(local * 1.6) * 0.03;
    }

    // ---- isi kotak (kertas) naik turun seolah "hidup" ----
    if (boxRef.current) {
      const rise = Math.min(1, local / 1.2);
      boxRef.current.position.y = THREE.MathUtils.lerp(-0.2, 0.18, rise) + Math.sin(local * 2.1) * 0.02;
      boxRef.current.rotation.y = Math.sin(local * 1.3) * 0.08;
    }
  });

  return (
    <group ref={groupRef}>
      {/* badan kotak */}
      <mesh geometry={boxGeo} castShadow receiveShadow>
        <meshStandardMaterial color="#b8916a" roughness={0.92} metalness={0} />
      </mesh>
      {/* strip lakban atas */}
      <mesh position={[0, 0.528, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[0.26, 1.16]} />
        <meshStandardMaterial color="#e9dcc2" roughness={0.75} metalness={0} transparent opacity={0.92} />
      </mesh>
      {/* kertas isi yang naik */}
      <group ref={boxRef}>
        <mesh geometry={paperGeo} castShadow>
          <meshStandardMaterial color="#efe7d8" roughness={0.85} metalness={0} />
        </mesh>
        {/* kartu terima kasih di atas kertas */}
        <mesh position={[0.15, 0.34, 0.05]} rotation={[THREE.MathUtils.degToRad(-64), THREE.MathUtils.degToRad(6), 0]}>
          <planeGeometry args={[0.5, 0.32]} />
          <meshStandardMaterial map={cardTex} roughness={0.85} metalness={0} side={THREE.DoubleSide} />
        </mesh>
      </group>
      {/* tutup melayang */}
      <group ref={lidRef} position={[0, 0.56, 0]}>
        <mesh geometry={lidGeo} castShadow>
          <meshStandardMaterial color="#a8845e" roughness={0.9} metalness={0} />
        </mesh>
      </group>
      {/* lantai penerima bayangan */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.85, 0]} receiveShadow>
        <planeGeometry args={[7, 7]} />
        <shadowMaterial opacity={0.18} />
      </mesh>
    </group>
  );
}

// ---- Loading screen -----------------------------------------------------

/**
 * Splash pembuka 3D: paket UNO Shop "membuka diri" — tutup melayang, kertas
 * pengisi & kartu terima kasih naik, kamera berputar satu putaran sinematik
 * sambil dolly-in. Tampil sekali per sesi browser. Device tanpa WebGL /
 * reduced-motion / low-end: fallback 2D (logo spring + progress bar) yang
 * tetap cantik — tidak pernah menggantung.
 */
export function LoadingScreen() {
  const [step, setStep] = useState<Step>("show");
  const [progress, setProgress] = useState(0);
  const [can3D, setCan3D] = useState(false);
  const [reduced, setReduced] = useState(false);

  useEffect(() => {
    let seen = false;
    try {
      seen = sessionStorage.getItem(SESSION_KEY) === "1";
    } catch {
      // Safari private mode dsb.
    }

    const prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    let webgl = false;
    try {
      const c = document.createElement("canvas");
      webgl = !!(c.getContext("webgl2") || c.getContext("webgl"));
    } catch {
      webgl = false;
    }
    const cores = navigator.hardwareConcurrency ?? 4;
    const lowEnd = cores <= 2;

    const timers: ReturnType<typeof setTimeout>[] = [];
    const show3D = !seen && !prefersReduced && webgl && !lowEnd;

    // Deteksi kemampuan di-apply async (bukan setState sinkron) supaya
    // tidak cascading render.
    const applyCap = () => {
      setCan3D(show3D);
      setReduced(prefersReduced);
    };

    if (seen) {
      timers.push(setTimeout(() => setStep("gone"), 0));
      return () => timers.forEach(clearTimeout);
    }

    try {
      sessionStorage.setItem(SESSION_KEY, "1");
    } catch {
      // abaikan
    }

    // Durasi tampil: 3D lebih lama agar animasi dinikmati; fallback cepat.
    const show = show3D ? PHASE_3D : prefersReduced ? 0 : 1200;
    if (show === 0) {
      timers.push(setTimeout(() => setStep("gone"), 0));
      return () => timers.forEach(clearTimeout);
    }

    // Progress halus dengan tick — sinkron dengan durasi show.
    const tick = setInterval(() => {
      setProgress((p) => {
        const next = p + 100 / (show / 100);
        return next >= 100 ? 100 : next;
      });
    }, 100);
    applyCap();
    timers.push(setTimeout(() => setStep("fading"), show));
    timers.push(setTimeout(() => setStep("gone"), show + FADE_MS));

    return () => {
      clearInterval(tick);
      timers.forEach(clearTimeout);
    };
  }, []);

  if (step === "gone") return null;

  const stage =
    [...STAGES].reverse().find((s) => progress / 100 >= s.at)?.label ?? STAGES[0].label;

  return (
    <motion.div
      className="fixed inset-0 z-[100] bg-[#0f1220] flex flex-col items-center justify-center overflow-hidden"
      initial={{ opacity: 1 }}
      animate={{ opacity: step === "fading" ? 0 : 1 }}
      transition={{ duration: FADE_MS / 1000, ease: [0.22, 1, 0.36, 1] }}
      aria-hidden="true"
    >
      {/* Latar bintang lembut untuk scene 3D */}
      {can3D && (
        <div className="absolute inset-0" aria-hidden="true">
          {Array.from({ length: 24 }).map((_, i) => (
            <span
              key={i}
              className="absolute rounded-full bg-white/25"
              style={{
                left: `${(i * 37) % 100}%`,
                top: `${(i * 53) % 100}%`,
                width: i % 5 === 0 ? 3 : 2,
                height: i % 5 === 0 ? 3 : 2,
                opacity: 0.1 + ((i * 13) % 40) / 100,
              }}
            />
          ))}
        </div>
      )}

      {can3D ? (
        /* ---- Splash 3D ---- */
        <>
          <div className="relative w-56 h-56 sm:w-64 sm:h-64">
            <Canvas
              shadows
              dpr={[1, 1.5]}
              gl={{ antialias: true, alpha: true }}
              camera={{ position: [2.6, 2.1, 4.2], fov: 34 }}
              onCreated={({ camera }) => camera.lookAt(0, 0.1, 0)}
            >
              <ambientLight intensity={0.45} color="#fff4e8" />
              <directionalLight
                position={[-3.2, 4.5, 3]}
                intensity={1.2}
                color="#fff2df"
                castShadow
                shadow-mapSize-width={1024}
                shadow-mapSize-height={1024}
                shadow-bias={-0.0015}
              />
              <directionalLight position={[3, 2, 2]} intensity={0.4} color="#a5c4ff" />
              <ParcelScene reducedMotion={false} />
            </Canvas>
          </div>

          <div className="relative mt-2 flex flex-col items-center gap-3">
            <motion.span
              className="text-sm font-semibold tracking-wide text-white"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              UNO Shop
            </motion.span>
            <div className="flex items-center gap-3 w-52">
              <div className="flex-1 h-1 rounded-full bg-white/15 overflow-hidden">
                <motion.div
                  className="h-full rounded-full bg-gradient-to-r from-blue-400 to-indigo-400"
                  style={{ width: `${progress}%` }}
                  transition={{ ease: "linear" }}
                />
              </div>
              <span className="text-[11px] tabular-nums text-white/50 w-8 text-right">
                {Math.round(progress)}%
              </span>
            </div>
            <span className="text-xs text-white/40 h-4">{stage}</span>
          </div>
        </>
      ) : (
        /* ---- Fallback 2D (reduced-motion / tanpa WebGL / low-end) ---- */
        <div className="flex flex-col items-center gap-5">
          <motion.div
            className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center shadow-xl shadow-blue-500/25"
            initial={reduced ? false : { scale: 0.6, opacity: 0, rotate: -8 }}
            animate={{ scale: 1, opacity: 1, rotate: 0 }}
            transition={reduced ? { duration: 0 } : { type: "spring", stiffness: 260, damping: 20 }}
          >
            <ShoppingBag size={28} className="text-white" />
          </motion.div>
          <div className="flex flex-col items-center gap-3">
            <span className="text-sm font-semibold tracking-wide text-white">UNO Shop</span>
            <div className="w-36 h-1 rounded-full bg-white/15 overflow-hidden">
              <motion.div
                className="h-full rounded-full bg-gradient-to-r from-blue-400 to-indigo-400"
                style={{ width: `${progress}%` }}
                transition={{ ease: "linear" }}
              />
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
}
