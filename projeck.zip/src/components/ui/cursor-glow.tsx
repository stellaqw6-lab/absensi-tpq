"use client";

import { useEffect, useRef } from "react";
import { useMotionPrefs } from "@/hooks/use-motion-prefs";

/**
 * CURSOR TRAIL GLOW — lapisan radial-gradient mengikuti kursor dengan trail
 * pegas (lerp di rAF), plus cincin halus yang tertinggal sedikit lebih jauh.
 * Efek kursor "premium" ala situs studio. Desktop saja (pointer presis +
 * hover); mobile sepenuhnya tidak dirender. Tanpa elemen per-frame React —
 * murni transform style via ref.
 */
export function CursorGlow() {
  const prefs = useMotionPrefs();
  const glowRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!prefs.allowMotion || !prefs.finePointer) return;
    const glow = glowRef.current;
    const ring = ringRef.current;
    if (!glow || !ring) return;

    // Posisi target (kursor) & posisi render (lerp lambat = trail).
    let tx = -300;
    let ty = -300;
    let gx = tx;
    let gy = ty;
    let rx = tx;
    let ry = ty;
    let raf = 0;
    let visible = false;
    let ringScale = 1;

    const onMove = (e: PointerEvent) => {
      tx = e.clientX;
      ty = e.clientY;
      if (!visible) {
        visible = true;
        glow.style.opacity = "1";
        ring.style.opacity = "1";
      }
      // Cincin membesar di atas elemen interaktif (link/tombol).
      const target = e.target as HTMLElement | null;
      const interactive = !!target?.closest("a, button, [role='button'], input, select, textarea");
      ringScale = interactive ? 1.7 : 1;
    };

    const onLeave = () => {
      visible = false;
      glow.style.opacity = "0";
      ring.style.opacity = "0";
    };

    const tick = () => {
      // Glow mengejar cepat (dekat kursor), cincin lebih malas (trail).
      gx += (tx - gx) * 0.18;
      gy += (ty - gy) * 0.18;
      rx += (tx - rx) * 0.1;
      ry += (ty - ry) * 0.1;
      glow.style.transform = `translate3d(${gx}px, ${gy}px, 0) translate(-50%, -50%)`;
      ring.style.transform = `translate3d(${rx}px, ${ry}px, 0) translate(-50%, -50%) scale(${ringScale})`;
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    window.addEventListener("pointermove", onMove, { passive: true });
    document.documentElement.addEventListener("pointerleave", onLeave);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("pointermove", onMove);
      document.documentElement.removeEventListener("pointerleave", onLeave);
    };
  }, [prefs.allowMotion, prefs.finePointer]);

  if (!prefs.allowMotion || !prefs.finePointer) return null;

  return (
    <>
      <div
        ref={glowRef}
        aria-hidden="true"
        className="pointer-events-none fixed left-0 top-0 z-[90] h-64 w-64 rounded-full opacity-0 transition-opacity duration-300 will-change-transform"
        style={{
          background:
            "radial-gradient(circle, rgba(37,99,235,0.10) 0%, rgba(99,102,241,0.05) 40%, transparent 65%)",
        }}
      />
      <div
        ref={ringRef}
        aria-hidden="true"
        className="pointer-events-none fixed left-0 top-0 z-[90] h-8 w-8 rounded-full border border-blue-500/30 opacity-0 transition-[opacity,transform] duration-300 will-change-transform"
      />
    </>
  );
}
