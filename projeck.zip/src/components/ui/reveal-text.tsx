"use client";

import { motion } from "framer-motion";
import { useMotionPrefs } from "@/hooks/use-motion-prefs";
import { durations, easeOutExpo } from "@/lib/motion";

interface RevealTextProps {
  text: string;
  /** Sudah punya margin sendiri di parent — komponen ini hanya animasi. */
  className?: string;
  as?: "h1" | "h2" | "h3";
  delayStep?: number;
}

/**
 * Judul yang muncul per kata (stagger) saat masuk viewport — sekali saja.
 * Boleh dipakai dari server component: props semuanya serializable.
 * Reduced-motion / device lemah: render teks biasa.
 */
export function RevealText({ text, className = "", as = "h2", delayStep = 0.06 }: RevealTextProps) {
  const prefs = useMotionPrefs();
  const words = text.split(" ");
  const Tag = motion[as];

  if (!prefs.allowMotion) {
    const Plain = as;
    return <Plain className={className}>{text}</Plain>;
  }

  return (
    <Tag
      className={className}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-40px" }}
      transition={{ staggerChildren: delayStep }}
    >
      {words.map((word, i) => (
        <span key={i} className="inline-block overflow-hidden align-bottom">
          <motion.span
            className="inline-block"
            variants={{
              hidden: { y: "110%", opacity: 0 },
              visible: { y: 0, opacity: 1, transition: { duration: durations.slow, ease: easeOutExpo } },
            }}
          >
            {word}
            {i < words.length - 1 ? "\u00A0" : ""}
          </motion.span>
        </span>
      ))}
    </Tag>
  );
}
