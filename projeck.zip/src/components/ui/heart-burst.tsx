"use client";

import { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useMotionPrefs } from "@/hooks/use-motion-prefs";

const PARTICLES = [
  { dx: -14, dy: -20, scale: 0.7, rot: -30 },
  { dx: 12, dy: -24, scale: 0.9, rot: 25 },
  { dx: -6, dy: -32, scale: 0.6, rot: 10 },
  { dx: 16, dy: -14, scale: 0.5, rot: -15 },
  { dx: -18, dy: -10, scale: 0.55, rot: 40 },
  { dx: 4, dy: -38, scale: 0.65, rot: -20 },
];

let burstId = 0;

/**
 * Partikel kecil yang meledak dari titik toggle — dipasang sebagai anak
 * absolut dari tombol wishlist. Panggil `trigger()` saat toggle ke-ON.
 * Contoh pemakaian:
 *   const [bursts, fire] = useHeartBurst();
 */
export function useHeartBurst() {
  const [bursts, setBursts] = useState<{ id: number }[]>([]);
  const trigger = useCallback(() => {
    const id = ++burstId;
    setBursts((b) => [...b, { id }]);
    setTimeout(() => setBursts((b) => b.filter((x) => x.id !== id)), 700);
  }, []);
  return { bursts, trigger };
}

export function HeartBurstView({ bursts }: { bursts: { id: number }[] }) {
  const prefs = useMotionPrefs();
  if (!prefs.allowMotion) return null;

  return (
    <span className="pointer-events-none absolute inset-0 flex items-center justify-center" aria-hidden="true">
      <AnimatePresence>
        {bursts.map((b) => (
          <motion.span key={b.id} className="absolute" initial={{ opacity: 1 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            {PARTICLES.map((p, i) => (
              <motion.svg
                key={i}
                viewBox="0 0 24 24"
                className="absolute w-3 h-3 text-red-500 fill-current"
                initial={{ x: 0, y: 0, scale: 0, rotate: 0, opacity: 1 }}
                animate={{
                  x: p.dx,
                  y: p.dy,
                  scale: p.scale,
                  rotate: p.rot,
                  opacity: 0,
                }}
                transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
              >
                <path d="M12 21s-6.7-4.3-9.3-8.5C.6 8.6 2.6 5 6 5c2 0 3.4 1.1 4.2 2.4L12 9l1.8-1.6C14.6 6.1 16 5 18 5c3.4 0 5.4 3.6 3.3 7.5C18.7 16.7 12 21 12 21z" />
              </motion.svg>
            ))}
          </motion.span>
        ))}
      </AnimatePresence>
    </span>
  );
}
