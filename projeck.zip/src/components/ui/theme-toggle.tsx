"use client";

import { useEffect, useState } from "react";
import { flushSync } from "react-dom";
import { useTheme } from "next-themes";
import { motion, AnimatePresence } from "framer-motion";
import { Sun, Moon } from "lucide-react";
import { useMotionPrefs } from "@/hooks/use-motion-prefs";

// Simpan posisi klik toggle untuk titik asal animasi circle-reveal.
let lastToggleX = 0.5;
let lastToggleY = 0.2;

export function getLastThemeToggleOrigin() {
  return { x: lastToggleX, y: lastToggleY };
}

/**
 * Toggle light/dark dengan dua lapis animasi:
 * 1. View Transitions API (browser modern): circle-reveal dari tombol —
 *    snapshot halaman lama lalu di-clip lingkaran mengembang. Chrome/Edge.
 * 2. Fallback + ikon: crossfade ikon Sun/Moon spring (semua browser),
 *    plus transisi warna halus di browser tanpa View Transitions.
 * Reduced-motion: ganti tema instan tanpa animasi.
 */
export function ThemeToggle({ className = "" }: { className?: string }) {
  const { theme, setTheme } = useTheme();
  const prefs = useMotionPrefs();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const raf = requestAnimationFrame(() => setMounted(true));
    return () => cancelAnimationFrame(raf);
  }, []);

  const handleToggle = (e: React.MouseEvent<HTMLButtonElement>) => {
    const next = theme === "dark" ? "light" : "dark";

    if (!prefs.allowMotion) {
      setTheme(next);
      return;
    }

    // Rekam posisi tombol relatif viewport untuk titik asal reveal.
    const rect = e.currentTarget.getBoundingClientRect();
    lastToggleX = (rect.left + rect.width / 2) / window.innerWidth;
    lastToggleY = (rect.top + rect.height / 2) / window.innerHeight;

    const doc = document as Document & {
      startViewTransition?: (cb: () => void) => { ready: Promise<void> };
    };

    if (typeof doc.startViewTransition === "function") {
      const transition = doc.startViewTransition(() => {
        // WAJIB flushSync: View Transitions mengambil snapshot DOM baru
        // segera setelah callback ini selesai. Tanpa flushSync, update state
        // React masih async → snapshot lama = snapshot baru → transisi
        // skipped/blanko dan browser melempar error.
        flushSync(() => {
          setTheme(next);
        });
      });
      // Setelah snapshot siap, animasikan clip-path lingkaran mengembang
      // dari posisi tombol ke seluruh layar.
      transition.ready.then(() => {
        const { x, y } = getLastThemeToggleOrigin();
        const radius = Math.hypot(Math.max(x, 1 - x), Math.max(y, 1 - y)) * 100;
        document.documentElement.animate(
          {
            clipPath: [
              `circle(0px at ${x * 100}% ${y * 100}%)`,
              `circle(${radius}vw at ${x * 100}% ${y * 100}%)`,
            ],
          },
          {
            duration: 550,
            easing: "cubic-bezier(0.22, 1, 0.36, 1)",
            pseudoElement: "::view-transition-new(root)",
          }
        );
      }).catch(() => {
        /* browser batal/timeout — tema tetap sudah berganti */
      });
    } else {
      setTheme(next);
    }
  };

  const isDark = theme === "dark";

  return (
    <button
      onClick={handleToggle}
      className={className}
      aria-label={isDark ? "Ganti ke mode terang" : "Ganti ke mode gelap"}
    >
      <span className="relative flex h-5 w-5 items-center justify-center">
        <AnimatePresence initial={false} mode="wait">
          {mounted ? (
            <motion.span
              key={isDark ? "sun" : "moon"}
              initial={{ rotate: -90, opacity: 0, scale: 0.5 }}
              animate={{ rotate: 0, opacity: 1, scale: 1 }}
              exit={{ rotate: 90, opacity: 0, scale: 0.5 }}
              transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
              className="flex"
            >
              {isDark ? <Sun size={20} /> : <Moon size={20} />}
            </motion.span>
          ) : (
            <Moon size={20} className="opacity-0" />
          )}
        </AnimatePresence>
      </span>
    </button>
  );
}
