"use client";

import { motion, useScroll, useSpring } from "framer-motion";

/**
 * Progress bar tipis di atas layar untuk artikel — ikuti posisi scroll.
 * GPU-only (scaleX), pasif terhadap scroll (tanpa listener manual).
 */
export function ReadingProgress() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 180, damping: 30, mass: 0.4 });

  return (
    <motion.div
      className="fixed top-0 inset-x-0 h-[3px] bg-blue-600 dark:bg-blue-500 origin-left z-[70]"
      style={{ scaleX }}
      aria-hidden="true"
    />
  );
}
