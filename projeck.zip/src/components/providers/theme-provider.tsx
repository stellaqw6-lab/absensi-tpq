"use client";

import { ThemeProvider as NextThemesProvider } from "next-themes";
import type { ReactNode } from "react";

export function ThemeProvider({ children }: { children: ReactNode }) {
  return (
    <NextThemesProvider
      attribute="class"
      defaultTheme="light"
      enableSystem
      // Jangan pakai disableTransitionOnChange: View Transitions API yang
      // mengurus animasi tema di browser modern, dan transisi warna CSS
      // halus jadi fallback di browser lain.
    >
      {children}
    </NextThemesProvider>
  );
}
