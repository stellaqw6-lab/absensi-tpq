"use client";

import { useRef } from "react";
import { motion } from "framer-motion";
import { Download, Printer, Store } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatCurrency } from "@/lib/utils";
import toast from "react-hot-toast";

export interface ReceiptOrder {
  orderNumber: string;
  status: string;
  paymentStatus: string;
  totalAmount: string;
  shippingCost: string;
  discountAmount: string;
  grandTotal: string;
  shippingAddress: string;
  paymentMethod: string | null;
  notes: string | null;
  createdAt: string;
}

export interface ReceiptItem {
  productName: string;
  variantName: string | null;
  price: string;
  quantity: number;
  subtotal: string;
}

const statusLabel: Record<string, string> = {
  pending: "Menunggu Konfirmasi",
  confirmed: "Dikonfirmasi",
  processing: "Diproses",
  shipped: "Dikirim",
  delivered: "Selesai",
  cancelled: "Dibatalkan",
  refunded: "Dana Dikembalikan",
};

/**
 * STRUK DIGITAL — tampil otomatis di halaman pesanan setelah pembayaran
 * lunas (paymentStatus "paid"). "Unduh" mencetak struk via dialog print
 * browser (bisa disimpan sebagai PDF); print CSS di globals.css memastikan
 * hanya elemen struk yang tercetak.
 */
export function Receipt({ order, items, siteName = "UNO Shop" }: { order: ReceiptOrder; items: ReceiptItem[]; siteName?: string }) {
  const ref = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    if (!ref.current) return;
    window.print();
    toast.success("Gunakan \"Save as PDF\" di dialog cetak untuk menyimpan struk");
  };

  const date = new Date(order.createdAt).toLocaleString("id-ID", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-2xl border border-green-100 p-6 mt-4 dark:bg-stone-900 dark:border-green-900/40"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-bold text-gray-900 dark:text-stone-100">Struk Pembayaran</h3>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handlePrint}>
            <Printer size={14} className="mr-1" /> Cetak
          </Button>
          <Button size="sm" onClick={handlePrint}>
            <Download size={14} className="mr-1" /> Unduh PDF
          </Button>
        </div>
      </div>

      {/* Area struk — satu-satunya yang tercetak (lihat print CSS globals) */}
      <div
        id="receipt-print"
        ref={ref}
        className="mx-auto max-w-sm rounded-lg border border-dashed border-gray-300 bg-white p-5 font-mono text-[11px] leading-relaxed text-gray-800 dark:border-stone-700 dark:bg-white"
      >
        <div className="text-center">
          <p className="flex items-center justify-center gap-1.5 text-sm font-bold tracking-wide uppercase">
            <Store size={14} /> {siteName}
          </p>
          <p className="text-[10px] text-gray-500">Struk Pembayaran — Bukti Transaksi</p>
        </div>

        <div className="my-3 border-t border-dashed border-gray-400" />

        <div className="flex justify-between">
          <span>No. Pesanan</span>
          <span className="font-semibold">{order.orderNumber}</span>
        </div>
        <div className="flex justify-between">
          <span>Tanggal</span>
          <span>{date}</span>
        </div>
        <div className="flex justify-between">
          <span>Pembayaran</span>
          <span>{order.paymentMethod ?? "-"}</span>
        </div>
        <div className="flex justify-between">
          <span>Status</span>
          <span className="font-semibold">{order.paymentStatus === "paid" ? "LUNAS" : order.paymentStatus.toUpperCase()}</span>
        </div>

        <div className="my-3 border-t border-dashed border-gray-400" />

        <table className="w-full">
          <tbody>
            {items.map((item, i) => (
              <tr key={i} className="align-top">
                <td className="pb-2">
                  <span className="block">{item.productName}</span>
                  {item.variantName && <span className="block text-[10px] text-gray-500">{item.variantName}</span>}
                  <span className="block text-[10px] text-gray-500">{item.quantity} x {formatCurrency(Number(item.price))}</span>
                </td>
                <td className="pb-2 text-right whitespace-nowrap">{formatCurrency(Number(item.subtotal))}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="my-3 border-t border-dashed border-gray-400" />

        <div className="flex justify-between">
          <span>Subtotal</span>
          <span>{formatCurrency(Number(order.totalAmount))}</span>
        </div>
        <div className="flex justify-between">
          <span>Pengiriman</span>
          <span>{Number(order.shippingCost) === 0 ? "—" : formatCurrency(Number(order.shippingCost))}</span>
        </div>
        {Number(order.discountAmount) > 0 && (
          <div className="flex justify-between">
            <span>Diskon</span>
            <span>-{formatCurrency(Number(order.discountAmount))}</span>
          </div>
        )}
        <div className="mt-2 flex justify-between border-t border-gray-400 pt-2 text-sm font-bold">
          <span>TOTAL</span>
          <span>{formatCurrency(Number(order.grandTotal))}</span>
        </div>

        <div className="my-3 border-t border-dashed border-gray-400" />

        <p className="text-[10px] text-gray-500">Alamat: {order.shippingAddress}</p>
        {order.notes && <p className="text-[10px] text-gray-500">Catatan: {order.notes}</p>}
        <p className="mt-3 text-center text-[10px] text-gray-500">
          Terima kasih sudah berbelanja di {siteName}!
          <br />
          Simpan struk ini sebagai bukti transaksi.
        </p>
        <div className="my-2 border-t border-dashed border-gray-400" />
        <p className="text-center text-[10px] text-gray-400"> Dicetak otomatis oleh sistem </p>
      </div>
    </motion.div>
  );
}
