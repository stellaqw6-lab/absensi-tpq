"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useScroll } from "@/hooks/use-scroll";
import { useMobile } from "@/hooks/use-mobile";
import { useSession } from "@/hooks/use-session";
import { useCart } from "@/contexts/cart-context";
import { useWishlist } from "@/contexts/wishlist-context";
import { useSellerUpgrade } from "@/contexts/seller-upgrade-context";
import { cn } from "@/lib/utils";
import {
  Search,
  ShoppingCart,
  Heart,
  User,
  LogOut,
  LayoutDashboard,
  Package,
  Store,
  Menu,
  X,
  ChevronDown,
  Sun,
  Moon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { motion, AnimatePresence } from "framer-motion";

const navLinks = [
  { label: "Beranda", href: "/" },
  {
    label: "Produk",
    href: "/produk",
    children: [
      { label: "Semua Produk", href: "/produk" },
      { label: "Best Seller", href: "/produk?sort=best-seller" },
      { label: "Produk Terbaru", href: "/produk?sort=terbaru" },
      { label: "Promo", href: "/promo" },
      { label: "Flash Sale", href: "/flash-sale" },
    ],
  },
  { label: "Tentang Kami", href: "/tentang-kami" },
  { label: "Blog", href: "/blog" },
  { label: "Kontak", href: "/kontak" },
];

export function Header() {
  const scrolled = useScroll(10);
  const isMobile = useMobile();
  const { user, logout } = useSession();
  const { openSellerUpgrade } = useSellerUpgrade();
  const { totalItems: cartCount } = useCart();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const { productIds: wishlistIds } = useWishlist();
  const wishlistCount = wishlistIds.size;
  const [siteName, setSiteName] = useState("UNO Shop");

  useEffect(() => {
    fetch("/api/settings")
      .then((res) => res.json())
      .then((data) => {
        if (data.settings?.siteName) setSiteName(data.settings.siteName);
      })
      .catch(() => {});
  }, []);

  return (
    <>
      {/* Main Header */}
      <header
        className={cn(
          "sticky top-0 z-50 bg-white border-b border-gray-100 dark:bg-stone-950 dark:border-stone-800",
          scrolled && "shadow-sm"
        )}
      >
        <div className="container mx-auto flex items-center gap-4 px-4 h-16">
          {/* Logo */}
          <Link
            href="/"
            className="flex items-center gap-2 text-lg font-bold tracking-tight shrink-0"
          >
            <div className="w-8 h-8 rounded-md bg-blue-600 flex items-center justify-center text-white text-sm font-bold">
              {siteName.charAt(0)}
            </div>
            <span className="hidden sm:block text-gray-900 dark:text-stone-100">{siteName}</span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-1 shrink-0">
            {navLinks.map((link) =>
              link.children ? (
                <DropdownMenu key={link.label} label={link.label}>
                  {link.children.map((child) => (
                    <Link
                      key={child.href}
                      href={child.href}
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-blue-600 transition-colors dark:text-stone-300 dark:hover:bg-stone-800"
                    >
                      {child.label}
                    </Link>
                  ))}
                </DropdownMenu>
              ) : (
                <Link
                  key={link.href}
                  href={link.href}
                  className="px-3 py-2 text-sm font-medium text-gray-700 hover:text-blue-600 rounded-md hover:bg-gray-50 transition-colors dark:text-stone-300 dark:hover:bg-stone-800"
                >
                  {link.label}
                </Link>
              )
            )}
          </nav>

          {/* Search — always visible on desktop */}
          <div className="hidden md:block flex-1 max-w-xl">
            <form action="/produk" className="relative">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-stone-500" />
              <input
                type="text"
                name="search"
                placeholder="Cari produk, toko, atau kategori..."
                className="w-full pl-9 pr-3 py-2 rounded-md border border-gray-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500/30 outline-none text-sm dark:border-stone-700 dark:bg-stone-900 dark:text-stone-100"
              />
            </form>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-1 ml-auto md:ml-0">
            {/* Search icon — mobile only */}
            <button
              onClick={() => setSearchOpen(!searchOpen)}
              className="p-2 min-w-11 min-h-11 flex items-center justify-center rounded-md text-gray-600 hover:text-blue-600 hover:bg-gray-50 transition-colors md:hidden dark:text-stone-400 dark:hover:bg-stone-800"
              aria-label="Search"
            >
              <Search size={20} />
            </button>

            {/* Theme Toggle — circle-reveal via View Transitions */}
            <ThemeToggle className="p-2 min-w-11 min-h-11 flex items-center justify-center rounded-md text-gray-600 hover:text-blue-600 hover:bg-gray-50 transition-colors dark:text-stone-400 dark:hover:bg-stone-800" />

            {/* Wishlist */}
            <Link
              href="/wishlist"
              className="relative p-2 min-w-11 min-h-11 flex items-center justify-center rounded-md text-gray-600 hover:text-blue-600 hover:bg-gray-50 transition-colors dark:text-stone-400 dark:hover:bg-stone-800"
            >
              <Heart size={20} />
              {wishlistCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-4.5 h-4.5 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center">
                  {wishlistCount}
                </span>
              )}
            </Link>

            {/* Cart */}
            <Link
              href="/cart"
              data-cart-icon
              className="relative p-2 min-w-11 min-h-11 flex items-center justify-center rounded-md text-gray-600 hover:text-blue-600 hover:bg-gray-50 transition-colors dark:text-stone-400 dark:hover:bg-stone-800"
            >
              <ShoppingCart size={20} />
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-4.5 h-4.5 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Link>

            {/* User */}
            {user ? (
              <div
                className="relative hidden sm:block"
                onMouseEnter={() => setUserMenuOpen(true)}
                onMouseLeave={() => setUserMenuOpen(false)}
              >
                <button className="flex items-center gap-2 p-2 rounded-md text-gray-600 hover:text-blue-600 hover:bg-gray-50 transition-colors dark:text-stone-400 dark:hover:bg-stone-800">
                  <div className="w-6 h-6 rounded-full bg-blue-600 flex items-center justify-center text-white text-[10px] font-bold">
                    {user.name.charAt(0)}
                  </div>
                  <span className="text-sm font-medium max-w-[100px] truncate dark:text-stone-200">{user.name}</span>
                </button>
                <AnimatePresence>
                  {userMenuOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 8 }}
                      className="absolute top-full right-0 mt-1 w-48 bg-white rounded-md border border-gray-200 shadow-sm py-1 z-50 dark:bg-stone-900 dark:border-stone-800"
                    >
                      {(user.role === "admin" || user.role === "superadmin") && (
                        <Link
                          href="/admin/dashboard"
                          className="flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-blue-600 transition-colors dark:text-stone-300 dark:hover:bg-stone-800"
                        >
                          <LayoutDashboard size={15} /> {user.role === "superadmin" ? "Dashboard Developer" : "Dashboard Admin"}
                        </Link>
                      )}
                      {user.role === "seller" && (
                        <Link
                          href="/seller/dashboard"
                          className="flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-emerald-600 transition-colors dark:text-stone-300 dark:hover:bg-stone-800"
                        >
                          <LayoutDashboard size={15} /> Dashboard Toko
                        </Link>
                      )}
                      {user.role === "customer" && (
                        <button
                          type="button"
                          onClick={() => {
                            setUserMenuOpen(false);
                            openSellerUpgrade();
                          }}
                          className="flex w-full items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-emerald-600 transition-colors text-left dark:text-stone-300 dark:hover:bg-stone-800"
                        >
                          <Store size={15} /> Upgrade Role Premium
                        </button>
                      )}
                      <Link
                        href="/pesanan"
                        className="flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-blue-600 transition-colors dark:text-stone-300 dark:hover:bg-stone-800"
                      >
                        <Package size={15} /> Pesanan Saya
                      </Link>
                      <button
                        onClick={logout}
                        className="flex w-full items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors dark:hover:bg-red-950/40"
                      >
                        <LogOut size={15} /> Keluar
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <Link
                href="/login"
                className="hidden sm:flex items-center gap-2 p-2 rounded-md text-gray-600 hover:text-blue-600 hover:bg-gray-50 transition-colors dark:text-stone-400 dark:hover:bg-stone-800"
              >
                <User size={20} />
                <span className="text-sm font-medium">Masuk</span>
              </Link>
            )}

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="lg:hidden p-2 min-w-11 min-h-11 flex items-center justify-center rounded-md text-gray-600 hover:text-blue-600 hover:bg-gray-50 transition-colors dark:text-stone-400 dark:hover:bg-stone-800"
              aria-label="Toggle menu"
            >
              {mobileOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>

        {/* Search Bar Expand */}
        <AnimatePresence>
          {searchOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="border-t border-gray-100 bg-white overflow-hidden md:hidden dark:bg-stone-950 dark:border-stone-800"
            >
              <div className="container mx-auto px-4 py-3">
                <form action="/produk" className="relative">
                  <Search
                    size={18}
                    className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 dark:text-stone-500"
                  />
                  <input
                    type="text"
                    name="search"
                    placeholder="Cari produk, toko, atau kategori..."
                    className="w-full pl-11 pr-4 py-2.5 rounded-md border border-gray-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500/30 outline-none text-sm dark:border-stone-700 dark:bg-stone-900 dark:text-stone-100"
                    autoFocus
                  />
                </form>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Mobile Menu */}
        <AnimatePresence>
          {mobileOpen && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="lg:hidden border-t border-gray-100 bg-white dark:bg-stone-950 dark:border-stone-800"
            >
              <nav className="container mx-auto px-4 py-4 flex flex-col gap-1">
                {navLinks.map((link) => (
                  <Link
                    key={link.href}
                    href={link.href}
                    onClick={() => setMobileOpen(false)}
                    className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-blue-600 hover:bg-gray-50 rounded-md transition-colors dark:text-stone-300 dark:hover:bg-stone-800"
                  >
                    {link.label}
                  </Link>
                ))}
                <hr className="my-2 dark:border-stone-800" />
                {user ? (
                  <>
                    {(user.role === "admin" || user.role === "superadmin") && (
                      <Link
                        href="/admin/dashboard"
                        onClick={() => setMobileOpen(false)}
                        className="px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-50 rounded-md transition-colors dark:text-stone-300 dark:hover:bg-stone-800"
                      >
                        {user.role === "superadmin" ? "Dashboard Developer" : "Dashboard Admin"}
                      </Link>
                    )}
                    {user.role === "seller" && (
                      <Link
                        href="/seller/dashboard"
                        onClick={() => setMobileOpen(false)}
                        className="px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-50 rounded-md transition-colors dark:text-stone-300 dark:hover:bg-stone-800"
                      >
                        Dashboard Toko
                      </Link>
                    )}
                    {user.role === "customer" && (
                      <button
                        type="button"
                        onClick={() => {
                          setMobileOpen(false);
                          openSellerUpgrade();
                        }}
                        className="text-left px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-50 rounded-md transition-colors dark:text-stone-300 dark:hover:bg-stone-800"
                      >
                        Upgrade Role Premium
                      </button>
                    )}
                    <Link
                      href="/pesanan"
                      onClick={() => setMobileOpen(false)}
                      className="px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-50 rounded-md transition-colors dark:text-stone-300 dark:hover:bg-stone-800"
                    >
                      Pesanan Saya
                    </Link>
                    <button
                      onClick={() => {
                        setMobileOpen(false);
                        logout();
                      }}
                      className="text-left px-4 py-3 text-sm font-medium text-red-600 hover:bg-red-50 rounded-md transition-colors dark:hover:bg-red-950/40"
                    >
                      Keluar ({user.name})
                    </button>
                  </>
                ) : (
                  <Link
                    href="/login"
                    onClick={() => setMobileOpen(false)}
                    className="px-4 py-3 text-sm font-medium text-blue-600 hover:bg-blue-50 rounded-md transition-colors dark:hover:bg-blue-950/40"
                  >
                    Masuk / Daftar
                  </Link>
                )}
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </header>
    </>
  );
}

function DropdownMenu({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);

  return (
    <div
      className="relative"
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
    >
      <button className="flex items-center gap-1 px-3 py-2 text-sm font-medium text-gray-700 hover:text-blue-600 rounded-lg hover:bg-gray-50 transition-all dark:text-stone-300 dark:hover:bg-stone-800">
        {label}
        <ChevronDown size={14} className={open ? "rotate-180 transition-transform" : "transition-transform"} />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            className="absolute top-full left-0 mt-2 w-52 bg-white rounded-md border border-gray-200 shadow-sm py-1 z-50 dark:bg-stone-900 dark:border-stone-800"
          >
            {children}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
