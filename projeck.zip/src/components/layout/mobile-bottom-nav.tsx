"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, Search, ShoppingCart, Heart, User } from "lucide-react";
import { useCart } from "@/contexts/cart-context";
import { useWishlist } from "@/contexts/wishlist-context";
import { useSession } from "@/hooks/use-session";
import { cn } from "@/lib/utils";

/**
 * Bottom tab bar untuk mobile/tablet (< lg, menyaingi nav desktop yang baru
 * muncul di lg+). Fixed bottom + safe-area inset untuk perangkat notch.
 */
export function MobileBottomNav() {
  const pathname = usePathname();
  const { totalItems: cartCount } = useCart();
  const { productIds: wishlistIds } = useWishlist();
  const { user } = useSession();

  const isActive = (href: string) =>
    href === "/" ? pathname === "/" : pathname.startsWith(href);

  const items = [
    { label: "Beranda", href: "/", icon: Home },
    { label: "Cari", href: "/produk", icon: Search },
    { label: "Keranjang", href: "/cart", icon: ShoppingCart, badge: cartCount },
    { label: "Wishlist", href: "/wishlist", icon: Heart, badge: wishlistIds.size },
    { label: "Akun", href: user ? "/pesanan" : "/login", icon: User },
  ];

  return (
    <nav
      className="fixed bottom-0 inset-x-0 z-40 lg:hidden bg-white/95 backdrop-blur border-t border-gray-100 dark:bg-stone-950/95 dark:border-stone-800"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
      aria-label="Navigasi utama mobile"
    >
      <div className="grid grid-cols-5 h-14">
        {items.map((item) => {
          const active = isActive(item.href);
          return (
            <Link
              key={item.label}
              href={item.href}
              data-cart-icon={item.href === "/cart" ? true : undefined}
              className={cn(
                "relative flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium transition-colors",
                active
                  ? "text-blue-600 dark:text-blue-400"
                  : "text-gray-500 dark:text-stone-400"
              )}
            >
              <span className="relative">
                <item.icon size={20} strokeWidth={active ? 2.2 : 1.8} />
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="absolute -top-1.5 -right-2 min-w-[16px] h-4 px-1 rounded-full bg-blue-600 text-white text-[9px] font-bold flex items-center justify-center">
                    {item.badge > 99 ? "99+" : item.badge}
                  </span>
                )}
              </span>
              {item.label}
              {active && (
                <span className="absolute top-0 inset-x-1/2 -translate-x-1/2 w-8 h-0.5 rounded-full bg-blue-600 dark:bg-blue-400" />
              )}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
