/**
 * Download file/gambar dari URL lewat fetch blob. Kalau fetch gagal
 * (mis. CORS memblokir), fallback buka gambar di tab baru supaya user
 * tetap bisa save manual — tidak pernah gagal total.
 */
export async function downloadFileFromUrl(url: string, filename: string): Promise<boolean> {
  try {
    const res = await fetch(url, { mode: "cors" });
    if (!res.ok) throw new Error("fetch failed");
    const blob = await res.blob();
    const objectUrl = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = objectUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(objectUrl), 2000);
    return true;
  } catch {
    window.open(url, "_blank", "noopener");
    return false;
  }
}
