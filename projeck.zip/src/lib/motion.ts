/**
 * Pasangan JS untuk motion tokens di globals.css (--duration-* /
 * --ease-out-*). Ubah keduanya bersamaan supaya konsisten.
 */
export const durations = {
  fast: 0.15,
  normal: 0.25,
  slow: 0.4,
  slower: 0.7,
} as const;

/** ease-out lembut — standar untuk masuk/muncul. */
export const easeOutExpo = [0.22, 1, 0.36, 1] as const;

/** Preset entrance standar dipakai framer-motion components. */
export const fadeUp = {
  initial: { opacity: 0, y: 16 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-40px" },
  transition: { duration: durations.slow, ease: easeOutExpo },
} as const;

export const fadeIn = {
  initial: { opacity: 0 },
  whileInView: { opacity: 1 },
  viewport: { once: true, margin: "-40px" },
  transition: { duration: durations.slow, ease: easeOutExpo },
} as const;

/** Stagger container untuk daftar anak motion. */
export const staggerContainer = (stagger = 0.08, delay = 0) =>
  ({
    initial: {},
    whileInView: { transition: { staggerChildren: stagger, delayChildren: delay } },
    viewport: { once: true, margin: "-40px" },
  }) as const;

/** Item anak untuk staggerContainer. */
export const staggerItem = {
  initial: { opacity: 0, y: 14 },
  whileInView: { opacity: 1, y: 0, transition: { duration: durations.slow, ease: easeOutExpo } },
} as const;
