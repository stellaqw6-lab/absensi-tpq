import { NextRequest, NextResponse } from "next/server";
import { verifySessionToken, SESSION_COOKIE } from "@/lib/auth";

// Halaman yang wajib login (mode "jelajah khusus member"): semua fitur
// browsing produk & transaksi. Halaman informatif (beranda, tentang-kami,
// kontak, faq) serta halaman auth tetap publik.
const MEMBER_ONLY_PAGES = [
  "/produk",
  "/promo",
  "/blog",
  "/cart",
  "/wishlist",
  "/checkout",
  "/pesanan",
  "/jadi-seller",
];

function isMemberOnlyPage(pathname: string) {
  return MEMBER_ONLY_PAGES.some((p) => pathname === p || pathname.startsWith(p + "/"));
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  const isAdminRoute = pathname.startsWith("/admin") || pathname.startsWith("/api/admin");
  const isSellerRoute = pathname.startsWith("/seller") || pathname.startsWith("/api/seller");

  // Endpoint ini khusus untuk customer MENGAJUKAN upgrade jadi seller — dia
  // justru dipakai SEBELUM user punya role seller, jadi tidak boleh ikut
  // aturan "harus sudah seller" di bawah. Validasi role-nya ditangani sendiri
  // oleh route handler (src/app/api/seller/upgrade-request/route.ts).
  const isUpgradeRequestRoute = pathname.startsWith("/api/seller/upgrade-request");

  const token = req.cookies.get(SESSION_COOKIE)?.value;
  const session = token ? await verifySessionToken(token) : null;

  // ---- Gating member-only: wajib login (role apapun) sebelum menjelajah ----
  if (!isAdminRoute && !isSellerRoute && isMemberOnlyPage(pathname)) {
    if (!session) {
      const loginUrl = new URL("/login", req.url);
      loginUrl.searchParams.set("redirect", pathname);
      loginUrl.searchParams.set("reason", "login_required");
      return NextResponse.redirect(loginUrl);
    }
    return NextResponse.next();
  }

  if (!isAdminRoute && !isSellerRoute) {
    return NextResponse.next();
  }

  if (isUpgradeRequestRoute) {
    return NextResponse.next();
  }

  const isAdmin = session && (session.role === "admin" || session.role === "superadmin");
  const isSellerOrAbove = session && (session.role === "seller" || session.role === "admin" || session.role === "superadmin");

  const allowed = isAdminRoute ? isAdmin : isSellerOrAbove;

  if (!allowed) {
    if (pathname.startsWith("/api/")) {
      return NextResponse.json({ error: "Akses ditolak." }, { status: 403 });
    }
    const loginUrl = new URL("/login", req.url);
    loginUrl.searchParams.set("redirect", pathname);
    loginUrl.searchParams.set("reason", isAdminRoute ? "admin_required" : "seller_required");
    return NextResponse.redirect(loginUrl);
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    "/admin/:path*",
    "/api/admin/:path*",
    "/seller/:path*",
    "/api/seller/:path*",
    "/produk/:path*",
    "/promo/:path*",
    "/blog/:path*",
    "/cart/:path*",
    "/wishlist/:path*",
    "/checkout/:path*",
    "/pesanan/:path*",
    "/jadi-seller/:path*",
  ],
};
