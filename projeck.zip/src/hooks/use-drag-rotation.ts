"use client";

import { useRef, useCallback } from "react";

interface DragRotationOptions {
  /** Derajat per pixel gerakan. */
  sensitivity?: number;
  axis?: "x" | "y";
  /** Batas absolut derajat (default tanpa batas untuk carousel). */
  clamp?: number | null;
}

interface DragRotationResult {
  /** Ref derajat rotasi — dibaca per-frame tanpa memicu re-render. */
  rotation: { current: number };
  /** Spread ke elemen pembungkus scene. */
  handlers: {
    onPointerDown: (e: React.PointerEvent<HTMLDivElement>) => void;
    onPointerMove: (e: React.PointerEvent<HTMLDivElement>) => void;
    onPointerUp: () => void;
    onPointerCancel: () => void;
  };
}

/**
 * Drag-to-rotate generik untuk scene 3D (kursor & sentuhan). Ref-based:
    nol re-render per gerakan — performa 60fps di mobile.
 */
export function useDragRotation({ sensitivity = 0.4, axis = "x", clamp = null }: DragRotationOptions = {}): DragRotationResult {
  const rotation = useRef(0);
  const drag = useRef({ active: false, last: 0 });

  const onPointerDown = useCallback((e: React.PointerEvent<HTMLDivElement>) => {
    drag.current = { active: true, last: axis === "x" ? e.clientX : e.clientY };
    e.currentTarget.setPointerCapture(e.pointerId);
  }, [axis]);

  const onPointerMove = useCallback((e: React.PointerEvent<HTMLDivElement>) => {
    if (!drag.current.active) return;
    const cur = axis === "x" ? e.clientX : e.clientY;
    const d = cur - drag.current.last;
    drag.current.last = cur;
    let next = rotation.current + d * sensitivity;
    if (clamp !== null) next = Math.min(clamp, Math.max(-clamp, next));
    rotation.current = next;
  }, [axis, sensitivity, clamp]);

  const end = useCallback(() => {
    drag.current.active = false;
  }, []);

  return {
    rotation,
    handlers: {
      onPointerDown,
      onPointerMove,
      onPointerUp: end,
      onPointerCancel: end,
    },
  };
}
