"use client";

import { useEffect, useState } from "react";

export interface SessionUser {
  id: number;
  name: string;
  email: string;
  role: "customer" | "seller" | "admin" | "superadmin";
}

// ---- Shared fetch cache ------------------------------------------------
// Satu request /api/auth/me dibagi semua pemanggil useSession di halaman
// (header, bottom nav, dsb.) — bukan satu fetch per komponen. Promise
// di-cache di module level; logout/login mengganti nilai `user` lewat
// setSessionUser sehingga semua consumer re-render bersamaan.
let sessionPromise: Promise<SessionUser | null> | null = null;
const listeners = new Set<(u: SessionUser | null) => void>();
let cachedUser: SessionUser | null = null;
let fetched = false;

function fetchSession(): Promise<SessionUser | null> {
  if (!sessionPromise) {
    sessionPromise = fetch("/api/auth/me")
      .then((res) => res.json())
      .then((data) => {
        cachedUser = data.user ?? null;
        fetched = true;
        return cachedUser;
      })
      .catch(() => {
        cachedUser = null;
        fetched = true;
        return null;
      });
  }
  return sessionPromise;
}

/** Update sesi dari luar (mis. setelah login) — semua consumer ikut berubah. */
export function setSessionUser(user: SessionUser | null) {
  cachedUser = user;
  fetched = true;
  sessionPromise = null;
  listeners.forEach((fn) => fn(user));
}

export function useSession() {
  // Lazy-init dari cache module — komponen yang mount setelah fetch selesai
  // langsung dapat nilai tanpa setState sinkron di effect.
  const [user, setUser] = useState<SessionUser | null>(() => cachedUser);
  const [loading, setLoading] = useState(() => !fetched);

  useEffect(() => {
    const onChange = (u: SessionUser | null) => {
      setUser(u);
      setLoading(false);
    };
    listeners.add(onChange);

    fetchSession().then((u) => onChange(u));

    return () => {
      listeners.delete(onChange);
    };
  }, []);

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    setSessionUser(null);
    window.location.href = "/";
  };

  return { user, loading, logout };
}
