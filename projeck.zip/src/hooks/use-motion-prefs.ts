"use client";

import { useEffect, useState } from "react";

export interface MotionPrefs {
  /** User minta gerak diminimalkan (OS setting). */
  reducedMotion: boolean;
  /** User aktifkan data-saver — hindari animasi berat. */
  saveData: boolean;
  /** Device kemungkinan lemah (sedikit core/memory) — animasi kuintasan saja. */
  lowEnd: boolean;
  /** Pointer presisi + hover tersedia (desktop) — interaksi magnetik/parallax boleh. */
  finePointer: boolean;
  /**
   * Gerak non-esensial boleh jalan. Animasi wajib fungsional (mis. indikator
   * loading) tetap boleh walau false — putuskan per komponen.
   */
  allowMotion: boolean;
}

function readPrefs(): MotionPrefs {
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const finePointer = window.matchMedia("(pointer: fine)").matches && window.matchMedia("(hover: hover)").matches;

  let saveData = false;
  let cores = 4;
  let memory: number | undefined;
  try {
    const conn = (navigator as unknown as { connection?: { saveData?: boolean } }).connection;
    saveData = !!conn?.saveData;
    cores = navigator.hardwareConcurrency ?? 4;
    memory = (navigator as unknown as { deviceMemory?: number }).deviceMemory;
  } catch {
    // browser tua / API diblokir — anggap default
  }
  const lowEnd = cores <= 2 || (memory !== undefined && memory <= 2);

  return { reducedMotion, saveData, lowEnd, finePointer, allowMotion: !reducedMotion && !saveData && !lowEnd };
}

const initial: MotionPrefs = {
  reducedMotion: false,
  saveData: false,
  lowEnd: false,
  finePointer: false,
  allowMotion: true,
};

/**
 * Preferensi gerak user/device, selalu SSR-safe (default netral di server,
 * re-read setelah mount). Listener change untuk reduced-motion otomatis
 * diperbarui. Pakai ini sebelum menyalakan efek animasi apapun.
 */
export function useMotionPrefs(): MotionPrefs {
  const [prefs, setPrefs] = useState<MotionPrefs>(initial);

  useEffect(() => {
    const update = () => setPrefs(readPrefs());
    update();

    const motionQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    motionQuery.addEventListener?.("change", update);
    return () => motionQuery.removeEventListener?.("change", update);
  }, []);

  return prefs;
}
